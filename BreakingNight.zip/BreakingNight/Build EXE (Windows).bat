@echo off
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
    echo Python is not installed. Get it from https://www.python.org/downloads/
    pause
    exit /b
)
echo === Installing the tools (one time only) ===
%PY% -m pip install --user --only-binary=:all: pygame-ce pyinstaller
echo === Building BreakingNight.exe - this takes a minute ===
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name BreakingNight ^
    --icon assets\icon.ico --add-data "assets;assets" breaking_night.py
if errorlevel 1 (
    echo Build failed.
    pause
    exit /b
)
copy /y "dist\BreakingNight.exe" "BreakingNight.exe" >nul
rmdir /s /q build >nul 2>nul
del /q BreakingNight.spec >nul 2>nul
echo.
echo ===================================================================
echo  DONE!  BreakingNight.exe is in this folder.
echo  Send just that one file to your friends - they double-click it.
echo  No Python needed on their computers.
echo ===================================================================
explorer /select,"%~dp0BreakingNight.exe"
pause
