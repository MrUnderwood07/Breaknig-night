"""Animated goth witch (antagonist) for Brick Builder.

    witch = WitchStage("path/to/sprites")      # witch_idle.png, witch_laugh.png, witch_anim.json
    witch.set_mode("idle")                      # main menu
    witch.set_mode("laugh")                     # game over - evil laughter
    witch.update(dt)
    witch.draw(target, rect, scale=3, foot=(x, y))

Look
  idle  : magic orb pulsing in her palm, sparkles circling it, purple mist at her feet, bats fluttering around
  laugh : head thrown back, glowing eyes, the orb flares and spits purple lightning,
          "HA!" letters burst from her mouth, the bats go wild, the stage darkens
"""
import json
import math
import os
import random

import pygame

ORB = [(255, 255, 255), (230, 180, 255), (170, 90, 240), (110, 40, 190), (60, 16, 110)]
BAT = [
    ["#.....#", "##...##", "###.###", ".#####.", "..#.#.."],     # wings up
    [".......", "...#...", "#######", "##...##", "#.....#"],     # wings down
]
GLYPHS = {
    "H": ["#..#", "#..#", "####", "#..#", "#..#"],
    "A": [".##.", "#..#", "####", "#..#", "#..#"],
    "!": ["#", "#", "#", ".", "#"],
}


def _pix(rows, color):
    s = pygame.Surface((len(rows[0]), len(rows)), pygame.SRCALPHA)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == "#":
                s.set_at((x, y), color)
    return s


def _word(text, color, outline=(30, 0, 40)):
    w = sum(len(GLYPHS[c][0]) + 1 for c in text) + 1
    s = pygame.Surface((w, 7), pygame.SRCALPHA)
    x = 1
    for c in text:
        g = GLYPHS[c]
        for oy in (-1, 0, 1):              # dark outline
            for ox in (-1, 0, 1):
                s.blit(_pix(g, outline), (x + ox, 1 + oy))
        s.blit(_pix(g, color), (x, 1))
        x += len(g[0]) + 1
    return s


class WitchStage:
    def __init__(self, sprite_dir):
        with open(os.path.join(sprite_dir, "witch_anim.json")) as f:
            meta = json.load(f)
        self.fw, self.fh = meta["frame_size"]
        self.cycles = {}
        for name, info in meta["cycles"].items():
            sheet = pygame.image.load(os.path.join(sprite_dir, f"witch_{name}.png"))
            if pygame.display.get_surface() is not None:
                sheet = sheet.convert_alpha()
            frames = [sheet.subsurface((i * self.fw, 0, self.fw, self.fh)).copy() for i in range(info["frames"])]
            self.cycles[name] = {"frames": frames, "anchors": info["anchors"]}
        self.bat_imgs = [_pix(b, (20, 10, 30)) for b in BAT]
        self.ha_imgs = [_word("HA", (230, 170, 255)), _word("HA", (200, 255, 160)), _word("HA!", (255, 255, 255))]
        self.mode = "idle"
        self.phase = 0.0
        self.t = 0.0
        self.mode_t = 0.0
        self.parts = []
        self.bolts = []
        self.bats = [[random.uniform(0, math.tau), random.uniform(0.6, 1.0), i] for i in range(3)]
        self.ha_acc = 0.0

    def set_mode(self, mode):
        if mode != self.mode:
            self.mode = mode
            self.phase = 0.0
            self.mode_t = 0.0

    def current(self):
        c = self.cycles[self.mode]
        i = int(self.phase * len(c["frames"])) % len(c["frames"])
        return c["frames"][i], c["anchors"][i]

    # ------------------------------------------------------------------ update
    def update(self, dt):
        self.t += dt
        self.mode_t += dt
        laughing = self.mode == "laugh"
        self.phase = (self.phase + dt / (1.0 if laughing else 2.4)) % 1.0
        frame, anc = self.current()
        rnd = random.random
        ox, oy = anc["orb"]
        # sparkles around the orb
        if rnd() < dt * (40 if laughing else 12):
            a = rnd() * math.tau
            r = 6 if laughing else 4
            self.parts.append(["spark", ox + math.cos(a) * r, oy + math.sin(a) * r,
                               math.cos(a) * 15, math.sin(a) * 15 - 10, 0.6, 0.6,
                               random.choice(((230, 180, 255), (180, 255, 150), (255, 255, 255)))])
        # mist at her feet
        if rnd() < dt * 18:
            fx = random.uniform(20, 76)
            self.parts.append(["mist", fx, 138 + rnd() * 4, random.uniform(-8, 8), -rnd() * 3, 2.0, 2.0, None])
        # evil laughter: "HA" letters and lightning
        if laughing:
            self.ha_acc += dt * 4
            while self.ha_acc > 1:
                self.ha_acc -= 1
                mx, my = anc["mouth"]
                self.parts.append(["ha", mx - 12, my - 2, random.uniform(-48, -30), random.uniform(-26, -8),
                                   1.4, 1.4, random.randrange(len(self.ha_imgs))])
            if rnd() < dt * 10:
                pts = [(ox, oy)]
                ang = random.uniform(-2.4, -0.7)
                ln = random.uniform(16, 40)
                for k in range(1, 6):
                    t = k / 5
                    pts.append((ox + math.cos(ang) * ln * t + random.uniform(-3, 3),
                                oy + math.sin(ang) * ln * t + random.uniform(-3, 3)))
                self.bolts.append((pts, self.t + 0.08))
        for p in self.parts:
            p[5] -= dt
            p[1] += p[3] * dt
            p[2] += p[4] * dt
            if p[0] == "ha":
                p[1] += math.sin(self.t * 10 + p[2]) * 10 * dt
        self.parts = [p for p in self.parts if p[5] > 0]
        self.bolts = [b for b in self.bolts if b[1] > self.t]
        speed = 2.6 if laughing else 1.0
        for b in self.bats:
            b[0] += dt * speed * b[1]

    # ------------------------------------------------------------------ draw
    def draw(self, target, rect, scale=3, foot=None):
        rect = pygame.Rect(rect)
        lw, lh = max(1, rect.w // scale), max(1, rect.h // scale)
        low = pygame.Surface((lw, lh), pygame.SRCALPHA)
        if foot is None:
            foot = (rect.w * 0.62, rect.h - 4 * scale)
        fx, fy = foot[0] / scale, foot[1] / scale
        ox, oy = fx - self.fw / 2, fy - (self.fh - 2)
        laughing = self.mode == "laugh"
        frame, anc = self.current()

        if laughing:                                       # the stage darkens
            k = min(1.0, self.mode_t / 0.6)
            shade = pygame.Surface((lw, lh), pygame.SRCALPHA)
            shade.fill((20, 0, 30, int(110 * k)))
            low.blit(shade, (0, 0))

        # purple aura behind her
        cx, cy = ox + 48, oy + 70
        pulse = 1 + 0.06 * math.sin(self.t * (12 if laughing else 3))
        for rad, a in ((62, 22), (48, 30), (34, 38)):
            rr = rad * pulse * (1.15 if laughing else 1)
            g = pygame.Surface((int(rr * 2), int(rr * 2.6)), pygame.SRCALPHA)
            pygame.draw.ellipse(g, (140, 50, 200, a), g.get_rect())
            low.blit(g, (cx - rr, cy - rr * 1.3))

        self._draw_bats(low, ox, oy, behind=True)
        for p in self.parts:
            if p[0] == "mist":
                f = p[5] / p[6]
                pygame.draw.ellipse(low, (150, 90, 200, int(70 * f)), (ox + p[1] - 6, oy + p[2] - 2, 12, 4))
        low.blit(frame, (ox, oy))

        # glowing eyes
        if laughing:
            for ex, ey in anc["eyes"]:
                g = pygame.Surface((9, 5), pygame.SRCALPHA)
                pygame.draw.ellipse(g, (220, 120, 255, 120), g.get_rect())
                low.blit(g, (ox + ex - 4, oy + ey - 2))

        # the magic orb
        obx, oby = ox + anc["orb"][0], oy + anc["orb"][1]
        base = 5 if laughing else 3
        r = base + math.sin(self.t * (14 if laughing else 4)) * (1.5 if laughing else 0.7)
        for i, c in enumerate(reversed(ORB)):
            rr = r * (1.9 - i * 0.35)
            if rr > 0.5:
                if i < 2:
                    g = pygame.Surface((int(rr * 2) + 2, int(rr * 2) + 2), pygame.SRCALPHA)
                    pygame.draw.circle(g, c + (90,), (int(rr) + 1, int(rr) + 1), int(rr))
                    low.blit(g, (obx - rr - 1, oby - rr - 1))
                else:
                    pygame.draw.circle(low, c, (int(obx), int(oby)), int(rr))
        for pts, _ in self.bolts:
            spts = [(ox + x, oy + y) for x, y in pts]
            pygame.draw.lines(low, (170, 90, 240), False, spts, 3)
            pygame.draw.lines(low, (255, 230, 255), False, spts, 1)

        for p in self.parts:
            if p[0] == "spark":
                low.fill(p[7], (int(ox + p[1]), int(oy + p[2]), 1, 1))
            elif p[0] == "ha":
                img = self.ha_imgs[p[7]]
                f = p[5] / p[6]
                sc = 2 if p[7] == 2 else 1
                im = pygame.transform.scale(img, (img.get_width() * sc, img.get_height() * sc)) if sc > 1 else img
                im.set_alpha(int(255 * min(1, f * 2)))
                low.blit(im, (ox + p[1] - im.get_width() / 2, oy + p[2]))
        self._draw_bats(low, ox, oy, behind=False)
        target.blit(pygame.transform.scale(low, (lw * scale, lh * scale)), rect.topleft)

    def _draw_bats(self, low, ox, oy, behind):
        for ang, sp, i in self.bats:
            depth = math.sin(ang)
            if (depth < 0) != behind:
                continue
            x = ox + 48 + math.cos(ang) * (38 + i * 6)
            y = oy + 40 + math.sin(ang * 2) * 10 - i * 8
            img = self.bat_imgs[int(self.t * (14 if self.mode == "laugh" else 8) + i) % 2]
            low.blit(img, (x - 3, y - 2))
