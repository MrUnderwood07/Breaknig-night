"""Animated rocker for Brick Builder.

    stage = HeroStage("path/to/sprites")      # folder with hero_play.png, hero_bang.png, hero_anim.json
    stage.trigger("MULTI")                     # instant power-ups: MULTI, LIFE
    stage.update(dt, effects)                  # effects = {"FIRE": seconds_left, ...} (like Game.effects)
    stage.draw(target_surface, rect, scale=3)  # draws the hero + effects into rect, pixel-art scaled

Behaviour
  * Tempo follows the song (128 BPM) and speeds up with every active power-up.
  * Two or more timed power-ups at once -> he starts HEADBANGING.
  * Each power-up has its own look:
      FIRE  burning aura            LASER  laser beams from his eyes
      FAST  red after-images        RUSH   lightning crackling off the guitar
      TURBO cyan thrusters in boots WIDE   grows bigger with a green power outline
      MULTI two ghost clones play   LIFE   a heart rises with a white shockwave
"""
import json
import math
import os
import random

import pygame

BPM = 128.0
BEAT = 60.0 / BPM
TEMPO_BOOST = {"FAST": 0.5, "RUSH": 0.7, "TURBO": 0.35, "FIRE": 0.25, "LASER": 0.25, "WIDE": 0.2}
EFFECT_COLORS = {"FIRE": (255, 120, 20), "LASER": (255, 60, 200), "FAST": (255, 70, 70),
                 "RUSH": (255, 220, 40), "TURBO": (0, 220, 255), "WIDE": (80, 255, 130)}
FIRE_RAMP = [(255, 255, 220), (255, 236, 120), (255, 180, 40), (255, 110, 20), (220, 50, 20), (120, 20, 20)]

NOTE_PIX = [  # 5x7 eighth note
    "..##.",
    "..#.#",
    "..#..",
    "..#..",
    "###..",
    "###..",
    ".#...",
]
HEART_PIX = [
    ".##.##.",
    "#######",
    "#######",
    ".#####.",
    "..###..",
    "...#...",
]


def _pix_surface(rows, color):
    s = pygame.Surface((len(rows[0]), len(rows)), pygame.SRCALPHA)
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == "#":
                s.set_at((x, y), color)
    return s


def _tint(surf, color, alpha):
    s = surf.copy()
    s.fill(color + (255,), special_flags=pygame.BLEND_RGBA_MULT)
    s.fill((color[0] // 3, color[1] // 3, color[2] // 3, 0), special_flags=pygame.BLEND_RGB_ADD)
    s.set_alpha(alpha)
    return s


class _P:
    __slots__ = ("x", "y", "vx", "vy", "life", "max", "kind", "c", "size")

    def __init__(self, x, y, vx, vy, life, kind, c=None, size=1):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.life = self.max = life
        self.kind, self.c, self.size = kind, c, size


class HeroStage:
    def __init__(self, sprite_dir):
        with open(os.path.join(sprite_dir, "hero_anim.json")) as f:
            meta = json.load(f)
        self.fw, self.fh = meta["frame_size"]
        self.cycles = {}
        for name, info in meta["cycles"].items():
            sheet = pygame.image.load(os.path.join(sprite_dir, f"hero_{name}.png"))
            if pygame.display.get_surface() is not None:
                sheet = sheet.convert_alpha()
            frames = [sheet.subsurface((i * self.fw, 0, self.fw, self.fh)).copy() for i in range(info["frames"])]
            outlines = [pygame.mask.from_surface(fr).outline(2) for fr in frames]
            self.cycles[name] = {"frames": frames, "anchors": info["anchors"], "outline": outlines}
        self.note_imgs = [_pix_surface(NOTE_PIX, c) for c in ((255, 255, 255), (255, 230, 120), (160, 220, 255))]
        self.heart = _pix_surface(HEART_PIX, (255, 60, 80))
        self.mode = "play"
        self.phase = 0.0
        self.t = 0.0
        self.effects = {}
        self.speed = 1.0
        self.scale_now = 1.0
        self.parts_back, self.parts_front = [], []
        self.bolts = []
        self.clones_t = 0.0
        self.life_t = 0.0
        self.note_acc = 0.0
        self.history = []

    # ------------------------------------------------------------------ control
    def trigger(self, kind):
        if kind == "MULTI":
            self.clones_t = 4.0
        elif kind == "LIFE":
            self.life_t = 1.6

    @property
    def headbanging(self):
        return len([k for k in self.effects if k in TEMPO_BOOST]) >= 2

    def current(self):
        c = self.cycles[self.mode]
        i = int(self.phase * len(c["frames"])) % len(c["frames"])
        return c["frames"][i], c["anchors"][i], c["outline"][i]

    # ------------------------------------------------------------------ update
    def update(self, dt, effects):
        self.t += dt
        self.effects = dict(effects or {})
        self.speed = min(3.0, 1.0 + sum(TEMPO_BOOST.get(k, 0) for k in self.effects))
        want = "bang" if self.headbanging else "play"
        if want != self.mode:
            self.mode = want
            if want == "bang":     # burst of sparks when the headbanging kicks in
                self._burst_head(20)
        cycle_len = (BEAT if self.mode == "bang" else 2 * BEAT) / self.speed
        self.phase = (self.phase + dt / cycle_len) % 1.0
        target = 1.2 if "WIDE" in self.effects else 1.0
        self.scale_now += (target - self.scale_now) * min(1, dt * 6)
        self.clones_t = max(0.0, self.clones_t - dt)
        self.life_t = max(0.0, self.life_t - dt)
        self._spawn(dt)
        for lst in (self.parts_back, self.parts_front):
            for p in lst:
                p.life -= dt
                p.x += p.vx * dt
                p.y += p.vy * dt
                if p.kind == "flame":
                    p.vx += math.sin(self.t * 9 + p.y * 0.3) * 30 * dt
                elif p.kind == "note":
                    p.vx = 10 + math.sin(self.t * 3 + p.y * 0.2) * 12
                elif p.kind == "spark":
                    p.vy += 120 * dt
            lst[:] = [p for p in lst if p.life > 0]
        self.bolts = [b for b in self.bolts if b[2] > self.t]

    # positions are in "hero space": the 96x144 frame, origin top-left of the frame
    def _spawn(self, dt):
        frame, anc, outline = self.current()
        rnd = random.random
        if "FIRE" in self.effects and outline:
            for _ in range(int(280 * dt * (0.7 + 0.3 * self.speed)) + 1):
                x, y = random.choice(outline)
                lst = self.parts_back if rnd() < 0.7 else self.parts_front
                lst.append(_P(x + rnd() * 2 - 1, y, rnd() * 10 - 5, -30 - rnd() * 50,
                              0.35 + rnd() * 0.5, "flame", size=1 + int(rnd() * 2.5)))
        if "TURBO" in self.effects:
            for fx, fy in anc["feet"]:
                for _ in range(int(110 * dt) + 1):          # exhaust jets blasting out of the heels
                    self.parts_back.append(_P(fx - 5 + rnd() * 3, fy - 4 + rnd() * 3, -50 - rnd() * 60,
                                              -8 + rnd() * 10, 0.2 + rnd() * 0.25, "turbo", size=1 + int(rnd() * 2)))
        if "LASER" in self.effects:
            for ex, ey in anc["eyes"]:
                if rnd() < dt * 30:
                    self.parts_front.append(_P(ex, ey, rnd() * 40 - 10, rnd() * 40 - 20, 0.2, "spark",
                                               (255, 160, 230)))
        if "RUSH" in self.effects and rnd() < dt * 14:
            hx, hy = anc["headstock"]
            ang = random.uniform(-2.6, 0.6)
            ln = random.uniform(25, 60)
            pts = [(hx, hy)]
            steps = 6
            for k in range(1, steps + 1):
                t = k / steps
                pts.append((hx + math.cos(ang) * ln * t + random.uniform(-4, 4),
                            hy + math.sin(ang) * ln * t + random.uniform(-4, 4)))
            self.bolts.append((pts, (255, 230, 60), self.t + 0.09))
            for _ in range(4):
                self.parts_front.append(_P(pts[-1][0], pts[-1][1], rnd() * 60 - 30, rnd() * 60 - 40, 0.3,
                                           "spark", (255, 240, 140)))
        # music notes float out of the guitar, more of them when he plays faster
        self.note_acc += dt * 1.6 * self.speed
        while self.note_acc > 1:
            self.note_acc -= 1
            gx, gy = anc["guitar"]
            self.parts_front.append(_P(gx + rnd() * 10, gy - 6, 10, -14 - rnd() * 10, 2.2, "note",
                                       c=random.randrange(3)))

    def _burst_head(self, n):
        frame, anc, _ = self.current()
        hx, hy = anc["head"]
        for _ in range(n):
            a = random.uniform(0, math.tau)
            s = random.uniform(30, 90)
            self.parts_front.append(_P(hx, hy, math.cos(a) * s, math.sin(a) * s - 30, 0.5, "spark",
                                       random.choice([(255, 255, 255), (255, 230, 120), (160, 220, 255)])))

    # ------------------------------------------------------------------ drawing
    def draw(self, target, rect, scale=3, foot=None):
        """Draw into `rect` of `target`. foot = (x, y) of the hero's feet inside rect (in target px)."""
        rect = pygame.Rect(rect)
        lw, lh = max(1, rect.w // scale), max(1, rect.h // scale)
        low = pygame.Surface((lw, lh), pygame.SRCALPHA)
        if foot is None:
            foot = (rect.w * 0.38, rect.h - 4 * scale)
        fx, fy = foot[0] / scale, foot[1] / scale
        k = self.scale_now
        ox, oy = fx - self.fw / 2 * k, fy - (self.fh - 2) * k     # top-left of the frame in low-res space

        def S(x, y):                       # hero space -> low-res stage space
            return ox + x * k, oy + y * k

        frame, anc, outline = self.current()
        if k != 1.0:
            hero = pygame.transform.scale(frame, (int(self.fw * k), int(self.fh * k)))
        else:
            hero = frame

        # glow aura behind him in the colour of the active effects
        cols = [EFFECT_COLORS[e] for e in self.effects if e in EFFECT_COLORS]
        if cols:
            r = sum(c[0] for c in cols) // len(cols)
            g = sum(c[1] for c in cols) // len(cols)
            b = sum(c[2] for c in cols) // len(cols)
            cx, cy = S(48, 72)
            pulse = 1 + 0.08 * math.sin(self.t * 2 * math.pi / (BEAT / self.speed))
            for i, (rad, a) in enumerate(((70, 28), (55, 36), (40, 44))):
                rr = rad * k * pulse
                glow = pygame.Surface((int(rr * 2), int(rr * 2.4)), pygame.SRCALPHA)
                pygame.draw.ellipse(glow, (r, g, b, a), glow.get_rect())
                low.blit(glow, (cx - rr, cy - rr * 1.2))

        # ghost clones (MULTI)
        if self.clones_t > 0:
            c = self.cycles[self.mode]
            n = len(c["frames"])
            fade = min(1.0, self.clones_t / 0.8, (4.0 - self.clones_t) / 0.3 + 0.01)
            spread = 30 * min(1.0, (4.0 - self.clones_t) / 0.3)
            for j, dx in enumerate((-spread, spread)):
                fr = c["frames"][(int(self.phase * n) + 3 + j * 3) % n]
                if k != 1.0:
                    fr = pygame.transform.scale(fr, hero.get_size())
                low.blit(_tint(fr, (190, 130, 255), int(150 * fade)), (ox + dx * k, oy))

        # after-images (FAST)
        self.history.append(hero)
        self.history = self.history[-12:]
        if "FAST" in self.effects:
            for j, idx in enumerate((-4, -8, -12)):
                if len(self.history) >= -idx:
                    jitter = math.sin(self.t * 20 + j) * 1.5
                    low.blit(_tint(self.history[idx], (255, 70, 70), 120 - j * 35), (ox - (j + 1) * 7 + jitter, oy))
            for j in range(6):                                   # speed lines
                y = (j * 23 + int(self.t * 37)) % lh
                x = (lw - (self.t * 300 + j * 97) % (lw + 60))
                pygame.draw.line(low, (255, 200, 200, 140), (x, y), (x + 25, y))

        # particles behind
        self._draw_particles(low, self.parts_back, S, k)

        # TURBO rings around the boots
        if "TURBO" in self.effects:
            for fxh, fyh in anc["feet"]:
                for j in range(2):
                    ph = (self.t * 2 + j * 0.5) % 1.0
                    cx, cy = S(fxh, fyh)
                    w = (10 + 14 * ph) * k
                    pygame.draw.ellipse(low, (0, 220, 255, int(200 * (1 - ph))),
                                        (cx - w / 2, cy - 2 - 8 * ph * k, w, w * 0.3), 1)

        # WIDE: green power outline
        if "WIDE" in self.effects:
            m = pygame.mask.from_surface(hero)
            sil = m.to_surface(setcolor=(80, 255, 130, 255), unsetcolor=(0, 0, 0, 0))
            a = int(140 + 100 * math.sin(self.t * 8))
            sil.set_alpha(max(0, a))
            for d in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                low.blit(sil, (ox + d[0], oy + d[1]))

        low.blit(hero, (ox, oy))

        # LASER eyes
        if "LASER" in self.effects:
            for i, (ex, ey) in enumerate(anc["eyes"]):
                sx, sy = S(ex, ey)
                ang = -0.12 + math.sin(self.t * 3 + i) * 0.04
                ex2, ey2 = lw + 10, sy + math.tan(ang) * (lw + 10 - sx)
                wob = 1 + (int(self.t * 30) % 2)
                pygame.draw.line(low, (255, 40, 180, 200), (sx, sy), (ex2, ey2), 2 + wob)
                pygame.draw.line(low, (255, 200, 240), (sx, sy), (ex2, ey2), 1)
                pygame.draw.circle(low, (255, 230, 250), (int(sx), int(sy)), 1 + wob)

        # RUSH lightning
        for pts, col, _ in self.bolts:
            spts = [S(x, y) for x, y in pts]
            pygame.draw.lines(low, (255, 160, 20), False, spts, 3)
            pygame.draw.lines(low, col, False, spts, 2)
            pygame.draw.lines(low, (255, 255, 255), False, spts, 1)

        # particles in front (front flames, notes, sparks)
        self._draw_particles(low, self.parts_front, S, k)

        # LIFE: heart + shockwave
        if self.life_t > 0:
            p = 1 - self.life_t / 1.6
            hx, hy = S(*anc["head"])
            hs = pygame.transform.scale(self.heart, (14, 12))
            hs.set_alpha(int(255 * min(1, self.life_t / 0.4)))
            low.blit(hs, (hx - 7, hy - 22 - 30 * p))
            rad = 10 + 90 * p
            pygame.draw.circle(low, (255, 255, 255, int(220 * (1 - p))), (int(hx), int(hy + 40)), int(rad), 2)

        target.blit(pygame.transform.scale(low, (lw * scale, lh * scale)), rect.topleft)

    def _draw_particles(self, low, lst, S, k):
        for p in lst:
            x, y = S(p.x, p.y)
            f = 1 - p.life / p.max
            if p.kind == "flame":
                c = FIRE_RAMP[min(len(FIRE_RAMP) - 1, int(f * len(FIRE_RAMP)))]
                low.fill(c, (int(x), int(y), p.size, p.size + 1))
            elif p.kind == "turbo":
                c = (200, 255, 255) if f < 0.3 else (0, 220, 255) if f < 0.7 else (0, 110, 200)
                low.fill(c, (int(x), int(y), p.size, p.size))
            elif p.kind == "spark":
                low.fill(p.c, (int(x), int(y), 1, 1))
            elif p.kind == "note":
                img = self.note_imgs[p.c]
                img.set_alpha(int(255 * min(1, p.life / 0.6)))
                low.blit(img, (int(x), int(y)))
