BREAKING NIGHT
==============

START
  Windows: double-click "Start Breaking Night (Windows).bat"
  Mac/Linux: pip install pygame-ce   then   python3 breaking_night.py

SHARE WITH FRIENDS (no Python needed on their PCs)
  1. Double-click "Build EXE (Windows).bat" (once, on your PC - takes about a minute).
  2. BreakingNight.exe appears in this folder - send just that file.
  3. Your friends double-click it. Saves and custom levels are kept next to the .exe.

SCREEN
  Left: the stage - the rocker plays along. Every power-up speeds him up and gives him
        its own effect; 2+ power-ups at once = HEADBANGING.
  Right: the playfield.
  Lose all lives and the witch appears and laughs at you.

MENU
  PLAY            10 campaign levels (clear one to unlock the next)
  CUSTOM LEVELS   your own levels
  LEVEL BUILDER   build levels
  SETTINGS        resolution (16:9), fullscreen, music and sound volume

PLAYING
  Mouse or Left/Right (A/D) move the bar, Space / click launches the ball and fires lasers,
  P pauses, Esc goes back.

POWER-UPS                             ROCKER'S EFFECT
  S  Speed Ball  ball faster, score x2      red after-images
  R  Rush Time   whole game faster, x3      lightning from the guitar
  T  Turbo Bar   bar 2x faster              thrusters in his boots
  M  Multi Ball  every ball splits in 3     two ghost clones play along
  F  Fireball    smashes through bricks     burning aura
  W  Wide Bar    bar 1.5x wider             he grows, green power outline
  L  Lasers      the bar shoots             lasers from his eyes
  +  Extra life                             a heart and a shockwave

SECRETS
  Click the witch in the main menu 3 times = CHEAT MODE: every campaign level unlocked.
  Beat all 10 campaign levels to see the ending.

LEVEL BUILDER
  Left mouse paint, right mouse erase; 1 2 3 bricks, 4 bomb, 5 wall, 0 eraser
  M mirror, C clear, S save, L reload, PgUp/PgDn slot, T test play, Esc menu
  Levels are saved in "custom_levels". Old levels from Brick Builder: copy the
  custom_levels folder from the old game folder into this one.

CREDITS
  Fonts: Orbitron and Press Start 2P, SIL Open Font License (assets/fonts).
  Music built from your own guitar riff.
