@echo off
cd /d "%~dp0"
set PY=
where py >nul 2>nul && set PY=py
if not defined PY where python >nul 2>nul && set PY=python
if not defined PY (
    echo Python is not installed.
    echo Download it from https://www.python.org/downloads/ and tick "Add python.exe to PATH" during setup.
    pause
    exit /b
)
%PY% -c "import pygame" >nul 2>nul || (
    echo Installing pygame-ce, one time only...
    %PY% -m pip install --user --only-binary=:all: pygame-ce || %PY% -m pip install --user --only-binary=:all: pygame
)
%PY% breaking_night.py
if errorlevel 1 pause
