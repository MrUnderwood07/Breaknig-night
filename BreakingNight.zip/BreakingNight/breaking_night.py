#!/usr/bin/env python3
"""
BREAKING NIGHT - a rock'n'roll Breakout with a level builder.

Requires Python 3.8+ and pygame-ce (or pygame):   pip install pygame-ce
Run:                                              python breaking_night.py

Files next to this script:
  hero_stage.py, witch_stage.py   animated characters
  assets/            music, sound effects, fonts, character sprites
  custom_levels/     levels made in the Level Builder (custom_01.json ...)
  settings.json      resolution, volume and campaign progress
"""
import json
import math
import os
import random
import sys

import pygame

sys.path.insert(0, os.path.dirname(os.path.abspath(sys.argv[0] if getattr(sys, "frozen", False) else __file__)))
try:
    from hero_stage import HeroStage
    from witch_stage import WitchStage
except ImportError:          # the game still runs without the character modules
    HeroStage = WitchStage = None

# --------------------------------------------------------------------------
# Layout / constants (the game is drawn at 960x720 and scaled to the window)
# --------------------------------------------------------------------------
W, H = 960, 720            # the playfield
CW = 1280                  # the whole screen (16:9): stage panel + playfield
PANEL_W = CW - W           # the rocker's stage on the left during play
FIELD_X = (CW - W) // 2    # menus that use the 960-wide layout are centred
HUD_H = 50
COLS, ROWS = 16, 18
TILE_W, TILE_H = W // COLS, 26
GRID_TOP = HUD_H + 10
GRID_BOTTOM = GRID_TOP + ROWS * TILE_H
PADDLE_Y = H - 50
PADDLE_H = 14
BASE_PADDLE_W = 120
BALL_R = 8
FPS = 120

EMPTY, BOMB, WALL = 0, 4, 9
BREAKABLE = (1, 2, 3, BOMB)
BRICK_COLORS = {1: (70, 190, 255), 2: (110, 225, 120), 3: (255, 165, 60)}
BOMB_COLOR = (215, 45, 55)
WALL_COLOR = (115, 120, 138)

START_SPEED = 430
MAX_SPEED = 700

POWERUPS = {
    "FAST":  dict(label="SPEED BALL", short="S", color=(255, 85, 85),  dur=10),
    "RUSH":  dict(label="RUSH TIME",  short="R", color=(255, 220, 0),  dur=8),
    "TURBO": dict(label="TURBO BAR",  short="T", color=(0, 225, 255),  dur=12),
    "MULTI": dict(label="MULTI BALL", short="M", color=(190, 120, 255), dur=0),
    "FIRE":  dict(label="FIREBALL",   short="F", color=(255, 120, 0),  dur=8),
    "WIDE":  dict(label="WIDE BAR",   short="W", color=(80, 255, 130), dur=15),
    "LASER": dict(label="LASERS",     short="L", color=(255, 60, 200), dur=10),
    "LIFE":  dict(label="EXTRA LIFE", short="+", color=(255, 255, 255), dur=0),
}
POWERUP_WEIGHTS = {"FAST": 16, "RUSH": 12, "TURBO": 14, "MULTI": 14,
                   "FIRE": 10, "WIDE": 14, "LASER": 12, "LIFE": 3}
DROP_CHANCE = 0.2

RESOLUTIONS = [(960, 540), (1024, 576), (1152, 648), (1280, 720), (1366, 768), (1600, 900),
               (1920, 1080), (2560, 1440)]
NEON_PINK, NEON_CYAN, NEON_YELLOW = (255, 46, 200), (0, 238, 255), (255, 230, 40)


def clamp(v, a, b):
    return a if v < a else b if v > b else v


def lighten(c, amt):
    return tuple(clamp(int(x + (255 - x) * amt), 0, 255) for x in c)


def darken(c, amt):
    return tuple(clamp(int(x * (1 - amt)), 0, 255) for x in c)


# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
def base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


BASE = base_dir()
# packed .exe: read-only assets live inside the bundle, saves stay next to the .exe
ASSETS = os.path.join(getattr(sys, "_MEIPASS", BASE), "assets")
CUSTOM_DIR = os.path.join(BASE, "custom_levels")
SETTINGS_PATH = os.path.join(BASE, "settings.json")


# --------------------------------------------------------------------------
# Levels
# --------------------------------------------------------------------------
def empty_grid():
    return [[EMPTY] * COLS for _ in range(ROWS)]


CHARS = {".": EMPTY, "1": 1, "2": 2, "3": 3, "B": BOMB, "#": WALL}


def sym(rows):
    """write only the left half (8 chars) - the right half is mirrored."""
    return [r + r[::-1] for r in rows]


def parse(rows):
    g = empty_grid()
    for r, row in enumerate(rows[:ROWS]):
        for c, ch in enumerate(row[:COLS]):
            g[r][c] = CHARS[ch]
    return g


CAMPAIGN = [
    ("First Steps", [
        "................",
        "................",
        "..222222222222..",
        "..111111111111..",
        "..111111111111..",
        "..111111111111..",
        "..111111111111..",
    ]),
    ("Stripes", [
        "................",
        ".33333333333333.",
        "................",
        ".22222B22B22222.",
        "................",
        ".11111111111111.",
        "................",
        ".11111111111111.",
    ]),
    ("Pyramid", sym([
        "........",
        ".......3",
        "......32",
        ".....322",
        "....3221",
        "...32211",
        "..322B11",
        ".3222111",
        "33333333",
    ])),
    ("Fortress", sym([
        "........",
        ".#333333",
        ".#333333",
        ".#222222",
        ".#222B22",
        ".#222222",
        ".#111111",
        ".#11111B",
        ".#111111",
        "........",
        "........",
        "######..",
    ])),
    ("Checkers", sym([
        "........",
        ".3.3.3.3",
        "2.2.2.2.",
        ".1.B.1.1",
        "2.2.2.2.",
        ".1.1.1.1",
        "1.1.1.1.",
        ".2.2.B.2",
        "1.1.1.1.",
    ])),
    ("Diamond", sym([
        "........",
        "#......1",
        "#.....12",
        ".....122",
        "....1233",
        "...12333",
        "..12333B",
        "...12333",
        "....1233",
        ".....122",
        "......12",
        ".......1",
        "........",
        "..#.....",
        "..#.....",
    ])),
    ("Corridors", sym([
        "33333333",
        "22222222",
        "........",
        "1.1#1.1.",
        "1.1#1.1.",
        "1B1#1B1.",
        "1.1#1.1.",
        "1.1#1.1.",
        "...#....",
    ])),
    ("Invader", sym([
        "........",
        "...3....",
        "....3...",
        "...33333",
        "..33B333",
        ".3333333",
        ".3.33333",
        ".3.3....",
        "....22..",
        "........",
        "........",
        "1.1.1.1.",
    ])),
    ("Bunker", sym([
        "........",
        ".#######",
        ".#333333",
        ".#3B2222",
        ".#322222",
        ".#3222B1",
        ".#311111",
        ".#311111",
        ".####...",
        "........",
        "..2..2..",
    ])),
    ("Final Boss", sym([
        "#3333333",
        "#33B3333",
        "#2222222",
        "#..#####",
        "........",
        "22222222",
        "2B2222B2",
        "11111111",
        "....##..",
        "........",
        "##......",
    ])),
]
CAMPAIGN = [(name, parse(rows)) for name, rows in CAMPAIGN]


def has_breakables(grid):
    return any(v in BREAKABLE for row in grid for v in row)


def custom_path(slot):
    return os.path.join(CUSTOM_DIR, f"custom_{slot:02d}.json")


def save_custom(slot, grid):
    os.makedirs(CUSTOM_DIR, exist_ok=True)
    with open(custom_path(slot), "w") as f:
        json.dump({"name": f"Custom {slot}", "grid": grid}, f)


def load_custom(slot):
    p = custom_path(slot)
    if not os.path.exists(p):
        return None
    try:
        with open(p) as f:
            raw = json.load(f).get("grid", [])
    except (OSError, ValueError, AttributeError):
        return None
    grid = empty_grid()
    for r in range(min(ROWS, len(raw))):
        for c in range(min(COLS, len(raw[r]))):
            v = raw[r][c]
            grid[r][c] = v if v in (EMPTY, 1, 2, 3, BOMB, WALL) else EMPTY
    return grid


def custom_levels():
    """[(slot, grid)] of saved custom levels that can be played."""
    out = []
    if os.path.isdir(CUSTOM_DIR):
        for name in os.listdir(CUSTOM_DIR):
            if name.startswith("custom_") and name.endswith(".json"):
                try:
                    slot = int(name[7:-5])
                except ValueError:
                    continue
                g = load_custom(slot)
                if g and has_breakables(g):
                    out.append((slot, g))
    return sorted(out)


# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------
def load_settings():
    s = {"resolution": None, "fullscreen": False, "music": 0.6, "sfx": 0.8, "unlocked": 1}
    try:
        with open(SETTINGS_PATH) as f:
            s.update(json.load(f))
    except (OSError, ValueError):
        pass
    return s


def save_settings(s):
    try:
        with open(SETTINGS_PATH, "w") as f:
            json.dump(s, f, indent=2)
    except OSError:
        pass


# --------------------------------------------------------------------------
# Audio
# --------------------------------------------------------------------------
class Audio:
    def __init__(self, settings):
        self.settings = settings
        self.ok = pygame.mixer.get_init() is not None
        self.sounds = {}
        self.last = {}
        self.track = None
        if not self.ok:
            return
        pygame.mixer.set_num_channels(24)
        sfx_dir = os.path.join(ASSETS, "sfx")
        if os.path.isdir(sfx_dir):
            for name in os.listdir(sfx_dir):
                if name.endswith((".wav", ".ogg")):
                    try:
                        self.sounds[name.rsplit(".", 1)[0]] = pygame.mixer.Sound(os.path.join(sfx_dir, name))
                    except pygame.error:
                        pass

    def play(self, name, vol=1.0):
        if not self.ok:
            return
        if name == "break":
            name = random.choice(("break_1", "break_2", "break_3"))
        snd = self.sounds.get(name)
        if not snd:
            return
        now = pygame.time.get_ticks()
        if now - self.last.get(name, -1000) < 35:   # avoid ear-splitting stacks
            return
        self.last[name] = now
        snd.set_volume(clamp(vol * self.settings["sfx"], 0, 1))
        snd.play()

    def music(self, track):
        if not self.ok or track == self.track:
            return
        path = os.path.join(ASSETS, f"music_{track}.ogg")
        if not os.path.exists(path):
            return
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(self.settings["music"])
            pygame.mixer.music.play(-1, fade_ms=700)
            self.track = track
        except pygame.error:
            pass

    def update_volume(self):
        if self.ok:
            pygame.mixer.music.set_volume(self.settings["music"])


# --------------------------------------------------------------------------
# Drawing helpers
# --------------------------------------------------------------------------
def tile_rect(c, r):
    return pygame.Rect(c * TILE_W, GRID_TOP + r * TILE_H, TILE_W, TILE_H)


def draw_tile(surf, v, rect, t=0.0):
    inner = rect.inflate(-4, -4)
    if v in BRICK_COLORS:
        col = BRICK_COLORS[v]
        pygame.draw.rect(surf, darken(col, 0.45), inner, border_radius=5)
        pygame.draw.rect(surf, col, inner.inflate(-2, -3).move(0, -1), border_radius=5)
        hl = pygame.Rect(inner.x + 5, inner.y + 3, inner.w - 10, 4)
        pygame.draw.rect(surf, lighten(col, 0.5), hl, border_radius=2)
        for i in range(v):  # hit-point pips
            pygame.draw.circle(surf, (255, 255, 255), (inner.right - 8 - i * 7, inner.bottom - 7), 2)
    elif v == BOMB:
        pygame.draw.rect(surf, darken(BOMB_COLOR, 0.45), inner, border_radius=5)
        pygame.draw.rect(surf, BOMB_COLOR, inner.inflate(-2, -3).move(0, -1), border_radius=5)
        pulse = 4 + 2 * math.sin(t * 7)
        pygame.draw.circle(surf, (255, 225, 80), inner.center, int(pulse + 2))
        pygame.draw.circle(surf, (255, 255, 220), inner.center, int(pulse / 2 + 1))
    elif v == WALL:
        pygame.draw.rect(surf, darken(WALL_COLOR, 0.5), rect.inflate(-1, -1))
        pygame.draw.rect(surf, WALL_COLOR, rect.inflate(-4, -4))
        for x in range(rect.x + 2, rect.right - 2, 10):
            pygame.draw.line(surf, darken(WALL_COLOR, 0.2), (x, rect.bottom - 3), (x + 8, rect.y + 3), 2)
        for px in (rect.x + 6, rect.right - 7):
            pygame.draw.circle(surf, lighten(WALL_COLOR, 0.5), (px, rect.centery), 2)


def draw_preview(surf, grid, rect):
    pygame.draw.rect(surf, (16, 18, 38), rect)
    cw, ch = rect.w / COLS, rect.h / ROWS
    for r in range(ROWS):
        for c in range(COLS):
            v = grid[r][c]
            if v:
                col = BRICK_COLORS.get(v, BOMB_COLOR if v == BOMB else WALL_COLOR)
                surf.fill(col, (rect.x + int(c * cw), rect.y + int(r * ch), max(1, int(cw) - 1), max(1, int(ch) - 1)))


def make_background():
    bg = pygame.Surface((W, H))
    for y in range(H):
        k = y / H
        bg.fill((int(12 + 18 * k), int(10 + 6 * k), int(32 + 30 * k)), (0, y, W, 1))
    rnd = random.Random(7)
    for _ in range(140):
        x, y = rnd.randrange(W), rnd.randrange(H)
        b = rnd.randrange(60, 160)
        bg.set_at((x, y), (b, b, b + 30))
    return bg


def text_center(app, surf, text, y, font, color, x=W // 2):
    img = font.render(text, True, color)
    surf.blit(img, img.get_rect(center=(x, y)))


def glow_of(img, spread=4):
    w, h = img.get_size()
    small = pygame.transform.smoothscale(img, (max(1, w // spread), max(1, h // spread)))
    return pygame.transform.smoothscale(small, (w, h))


def neon_text(surf, text, font, center, color=NEON_PINK, core=(255, 255, 255), t=0.0, glitch=True, split=3):
    """Cyberpunk neon: coloured glow, chromatic split (pink / cyan), white-hot core, occasional glitch."""
    body = font.render(text, True, color)
    pad = 24
    tmp = pygame.Surface((body.get_width() + pad * 2, body.get_height() + pad * 2), pygame.SRCALPHA)
    halo = pygame.Surface(tmp.get_size(), pygame.SRCALPHA)
    halo.blit(body, (pad, pad))
    g = glow_of(halo, 6)
    tmp.blit(g, (0, 0))
    tmp.blit(g, (0, 0))
    tmp.blit(font.render(text, True, NEON_PINK), (pad - split, pad))
    tmp.blit(font.render(text, True, NEON_CYAN), (pad + split, pad))
    tmp.blit(font.render(text, True, core), (pad, pad))
    r = tmp.get_rect(center=center)
    phase = (t * 0.37) % 1.0
    if glitch and phase < 0.06:                      # brief horizontal slice glitch every few seconds
        rnd = random.Random(int(t * 30))
        y = 0
        while y < tmp.get_height():
            hgt = rnd.randint(3, 12)
            off = rnd.choice((0, 0, rnd.randint(-14, 14)))
            surf.blit(tmp, (r.x + off, r.y + y), (0, y, tmp.get_width(), hgt))
            y += hgt
    else:
        surf.blit(tmp, r)
    return r


def chamfer(rect, c=10):
    x, y, w, h = rect
    return [(x + c, y), (x + w - 1, y), (x + w - 1, y + h - 1 - c), (x + w - 1 - c, y + h - 1),
            (x, y + h - 1), (x, y + c)]


def draw_button(app, surf, rect, label, on, font=None):
    rect = pygame.Rect(rect)
    pts = chamfer(rect, 12)
    if on:
        glow = pygame.Surface((rect.w + 30, rect.h + 30), pygame.SRCALPHA)
        pygame.draw.polygon(glow, NEON_CYAN + (90,), [(x - rect.x + 15, y - rect.y + 15) for x, y in pts], 6)
        surf.blit(glow_of(glow, 3), (rect.x - 15, rect.y - 15))
    pygame.draw.polygon(surf, (40, 18, 70) if on else (16, 14, 34), pts)
    pygame.draw.polygon(surf, NEON_CYAN if on else (80, 60, 130), pts, 2)
    if on:
        pygame.draw.line(surf, NEON_PINK, (rect.x + 14, rect.bottom - 4), (rect.x + rect.w // 3, rect.bottom - 4), 2)
    img = (font or app.font_big).render(label, True, (255, 255, 255) if on else (170, 160, 210))
    surf.blit(img, img.get_rect(center=rect.center))


def make_night():
    """Low-res (1/3) night scene: moon, castle, graveyard. Scaled up 3x when used."""
    lw, lh = CW // 3, H // 3
    bg = pygame.Surface((lw, lh))
    for y in range(lh):
        k = y / lh
        bg.fill((int(10 + 30 * k), int(6 + 10 * k), int(26 + 34 * k)), (0, y, lw, 1))
    rnd = random.Random(3)
    for _ in range(120):
        b = rnd.randrange(90, 200)
        bg.set_at((rnd.randrange(lw), rnd.randrange(lh - 60)), (b, b, b + 40))
    pygame.draw.circle(bg, (230, 226, 210), (372, 34), 18)
    pygame.draw.circle(bg, (205, 200, 186), (366, 29), 4)
    pygame.draw.circle(bg, (205, 200, 186), (379, 41), 3)
    sil = (16, 10, 26)
    base = lh - 26
    for (x, w, h) in ((290, 20, 60), (310, 50, 40), (360, 14, 74), (374, 40, 46), (410, 16, 58)):
        pygame.draw.rect(bg, sil, (x, base - h, w, h))
        for cx in range(x, x + w, 5):
            pygame.draw.rect(bg, sil, (cx, base - h - 3, 3, 3))
    pygame.draw.polygon(bg, sil, [(360, base - 74), (367, base - 92), (374, base - 74)])
    for (x, y) in ((366, base - 60), (320, base - 30), (416, base - 44)):
        bg.fill((255, 200, 90), (x, y, 2, 3))
    # neon city glow on the horizon (cyberpunk touch)
    for i, (x, w, h, col) in enumerate(((10, 18, 40, NEON_PINK), (34, 12, 56, NEON_CYAN), (52, 22, 32, NEON_PINK),
                                         (200, 16, 44, NEON_CYAN), (222, 20, 30, NEON_PINK))):
        pygame.draw.rect(bg, (18, 12, 30), (x, base - h, w, h))
        for wy in range(base - h + 4, base - 2, 5):
            for wx in range(x + 2, x + w - 2, 4):
                if rnd.random() < 0.4:
                    bg.set_at((wx, wy), col)
    bg.fill((22, 18, 30), (0, base, lw, lh - base))
    pygame.draw.line(bg, (90, 30, 110), (0, base), (lw, base))
    for x in (90, 130, 170, 250):
        pygame.draw.rect(bg, (40, 36, 50), (x, base - 10, 8, 10))
        pygame.draw.circle(bg, (40, 36, 50), (x + 4, base - 10), 4)
    return pygame.transform.scale(bg, (CW, H))


def make_stage_panel():
    """Low-res club stage behind the rocker (PANEL_W x H at 1/3 scale)."""
    lw, lh = PANEL_W // 3, H // 3
    bg = pygame.Surface((lw, lh))
    for y in range(lh):
        k = y / lh
        bg.fill((int(10 + 22 * k), int(6 + 8 * k), int(22 + 30 * k)), (0, y, lw, 1))
    floor = lh - 16
    bg.fill((48, 30, 22), (0, floor, lw, lh - floor))
    for x in range(0, lw, 12):
        pygame.draw.line(bg, (34, 20, 14), (x, floor), (x - 6, lh))
    pygame.draw.line(bg, (90, 60, 40), (0, floor), (lw, floor))
    for j in range(3):                                            # amp stack at the back
        r = pygame.Rect(lw - 30, floor - 24 - j * 24, 28, 22)
        pygame.draw.rect(bg, (24, 22, 26), r)
        pygame.draw.rect(bg, (60, 58, 66), r, 1)
        pygame.draw.circle(bg, (40, 38, 44), (r.x + 8, r.y + 11), 5)
        pygame.draw.circle(bg, (40, 38, 44), (r.x + 20, r.y + 11), 5)
    return bg


# --------------------------------------------------------------------------
# Game objects
# --------------------------------------------------------------------------
class Ball:
    def __init__(self, x, y, vx=0.0, vy=0.0, stuck=False):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.stuck = stuck
        self.offset = 0.0
        self.trail = []
        self.dead = False


class Particle:
    def __init__(self, x, y, color, speed=220, size=4, life=0.6):
        a = random.uniform(0, math.tau)
        s = random.uniform(0.3, 1.0) * speed
        self.x, self.y = x, y
        self.vx, self.vy = math.cos(a) * s, math.sin(a) * s
        self.color, self.size = color, size
        self.life = self.max_life = random.uniform(0.5, 1.0) * life


class PowerUp:
    def __init__(self, x, y, kind):
        self.x, self.y, self.kind = x, y, kind

    @property
    def rect(self):
        return pygame.Rect(self.x - 24, self.y - 10, 48, 20)


# --------------------------------------------------------------------------
# Scenes
# --------------------------------------------------------------------------
class Menu:
    OPTIONS = ["PLAY", "CUSTOM LEVELS", "LEVEL BUILDER", "SETTINGS", "QUIT"]
    music = "menu"
    layout = "full"
    field_x = 0

    WITCH_HITBOX = pygame.Rect(1000, 220, 170, 430)

    def __init__(self, app, msg="", sel=0):
        self.app = app
        self.sel = sel
        self.msg = msg
        self.msg_col = (255, 120, 160)
        self.t = 0.0
        self.witch_clicks = []
        self.laugh_t = 0.0
        if app.witch:
            app.witch.set_mode("idle")

    def poke_witch(self):
        app = self.app
        now = self.t
        self.witch_clicks = [c for c in self.witch_clicks if now - c < 2.5] + [now]
        app.audio.play("pong_wall")
        if len(self.witch_clicks) >= 3:
            self.witch_clicks = []
            app.settings["unlocked"] = len(CAMPAIGN)
            save_settings(app.settings)
            app.audio.play("clear")
            self.msg, self.msg_col = "CHEAT MODE: ALL 10 LEVELS UNLOCKED!", NEON_YELLOW
            self.laugh_t = 2.2
            if app.witch:
                app.witch.set_mode("laugh")

    def option_rect(self, i):
        return pygame.Rect(CW // 2 - 170, 270 + i * 66, 340, 52)

    def choose(self, i):
        self.app.audio.play("click")
        opt = self.OPTIONS[i]
        if opt == "PLAY":
            self.app.scene = LevelSelect(self.app, "campaign")
        elif opt == "CUSTOM LEVELS":
            if not custom_levels():
                self.msg, self.msg_col = "No custom levels yet - build one first!", (255, 120, 160)
                return
            self.app.scene = LevelSelect(self.app, "custom")
        elif opt == "LEVEL BUILDER":
            self.app.scene = Builder(self.app)
        elif opt == "SETTINGS":
            self.app.scene = Settings(self.app)
        else:
            self.app.running = False

    def handle_event(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_UP, pygame.K_w):
                self.sel = (self.sel - 1) % len(self.OPTIONS)
            elif e.key in (pygame.K_DOWN, pygame.K_s):
                self.sel = (self.sel + 1) % len(self.OPTIONS)
            elif e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                self.choose(self.sel)
            elif e.key == pygame.K_ESCAPE:
                self.app.running = False
        elif e.type == pygame.MOUSEMOTION:
            for i in range(len(self.OPTIONS)):
                if self.option_rect(i).collidepoint(e.pos):
                    self.sel = i
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i in range(len(self.OPTIONS)):
                if self.option_rect(i).collidepoint(e.pos):
                    self.choose(i)
            if self.WITCH_HITBOX.collidepoint(e.pos):
                self.poke_witch()

    def update(self, dt):
        self.t += dt
        if self.laugh_t > 0:
            self.laugh_t -= dt
            if self.laugh_t <= 0 and self.app.witch:
                self.app.witch.set_mode("idle")
        if self.app.hero:
            self.app.hero.update(dt, {})
        if self.app.witch:
            self.app.witch.update(dt)

    def draw(self, surf):
        app = self.app
        surf.blit(app.night, (0, 0))
        if app.hero:
            app.hero.draw(surf, surf.get_rect(), 3, foot=(205, H - 72))
        if app.witch:
            app.witch.draw(surf, surf.get_rect(), 3, foot=(1075, H - 72))
        neon_text(surf, "BREAKING NIGHT", app.font_title, (CW // 2, 120 + math.sin(self.t * 2) * 4), t=self.t)
        text_center(app, surf, "BREAK BRICKS - BUILD LEVELS - ROCK THE NIGHT", 200, app.font_small, NEON_YELLOW, CW // 2)
        for i, opt in enumerate(self.OPTIONS):
            draw_button(app, surf, self.option_rect(i), opt, i == self.sel)
        if self.msg:
            text_center(app, surf, self.msg, 625, app.font, self.msg_col, CW // 2)
        text_center(app, surf, "ARROWS / MOUSE - ENTER - ESC TO QUIT", 700, app.font_tiny, (150, 140, 190), CW // 2)


class LevelSelect:
    music = "menu"
    layout = "field"
    field_x = FIELD_X
    PER_PAGE = 10

    def __init__(self, app, mode):
        self.app = app
        self.mode = mode
        self.t = 0.0
        if mode == "campaign":
            self.entries = [(f"{i + 1}. {name}", grid) for i, (name, grid) in enumerate(CAMPAIGN)]
            self.unlocked = clamp(int(app.settings.get("unlocked", 1)), 1, len(CAMPAIGN))
            self.sel = self.unlocked - 1
        else:
            self.entries = [(f"Custom {slot}", grid) for slot, grid in custom_levels()]
            self.unlocked = len(self.entries)
            self.sel = 0

    def tile_rect(self, i):
        i %= self.PER_PAGE
        col, row = i % 5, i // 5
        return pygame.Rect(22 + col * 186, 150 + row * 220, 172, 196)

    def page(self):
        return self.sel // self.PER_PAGE

    def start(self, i):
        if i >= self.unlocked:
            self.app.audio.play("lose", 0.5)
            return
        self.app.audio.play("click")
        self.app.scene = Game(self.app, self.entries, start=i, campaign=self.mode == "campaign")

    def handle_event(self, e):
        n = len(self.entries)
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.app.scene = Menu(self.app, sel=0 if self.mode == "campaign" else 1)
            elif e.key in (pygame.K_RIGHT, pygame.K_d):
                self.sel = min(n - 1, self.sel + 1)
            elif e.key in (pygame.K_LEFT, pygame.K_a):
                self.sel = max(0, self.sel - 1)
            elif e.key in (pygame.K_DOWN, pygame.K_s):
                self.sel = min(n - 1, self.sel + 5)
            elif e.key in (pygame.K_UP, pygame.K_w):
                self.sel = max(0, self.sel - 5)
            elif e.key == pygame.K_PAGEDOWN:
                self.sel = min(n - 1, self.sel + self.PER_PAGE)
            elif e.key == pygame.K_PAGEUP:
                self.sel = max(0, self.sel - self.PER_PAGE)
            elif e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                self.start(self.sel)
        elif e.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            first = self.page() * self.PER_PAGE
            for i in range(first, min(n, first + self.PER_PAGE)):
                if self.tile_rect(i).collidepoint(e.pos):
                    self.sel = i
                    if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                        self.start(i)
            if e.type == pygame.MOUSEBUTTONDOWN and e.button in (4, 5):
                step = self.PER_PAGE if e.button == 5 else -self.PER_PAGE
                self.sel = clamp(self.sel + step, 0, n - 1)

    def update(self, dt):
        self.t += dt

    def draw(self, surf):
        app = self.app
        surf.blit(app.bg, (0, 0))
        title = "CAMPAIGN" if self.mode == "campaign" else "CUSTOM LEVELS"
        neon_text(surf, title, app.font_huge, (W // 2, 66), t=self.t, glitch=False, split=2)
        first = self.page() * self.PER_PAGE
        for i in range(first, min(len(self.entries), first + self.PER_PAGE)):
            name, grid = self.entries[i]
            r = self.tile_rect(i)
            on = i == self.sel
            locked = i >= self.unlocked
            pygame.draw.rect(surf, (50, 58, 120) if on else (26, 28, 56), r, border_radius=10)
            pygame.draw.rect(surf, (255, 230, 120) if on else (70, 75, 120), r, 2, border_radius=10)
            prev = pygame.Rect(r.x + 10, r.y + 10, 152, 138)
            draw_preview(surf, grid, prev)
            if locked:
                shade = pygame.Surface(prev.size, pygame.SRCALPHA)
                shade.fill((0, 0, 0, 190))
                surf.blit(shade, prev)
                text_center(app, surf, "LOCKED", prev.centery, app.font_bold, (200, 200, 220), prev.centerx)
            label = name
            while app.font_small.size(label)[0] > 150 and len(label) > 4:
                label = label[:-4] + "..."
            text_center(app, surf, label, r.bottom - 26, app.font_small,
                        (255, 255, 255) if not locked else (120, 120, 150), r.centerx)
        pages = (len(self.entries) - 1) // self.PER_PAGE + 1
        hint = "Arrows / mouse to choose  -  Enter to play  -  Esc to go back"
        if pages > 1:
            hint = f"Page {self.page() + 1}/{pages} (PgUp / PgDn)  -  " + hint
        text_center(app, surf, hint, 690, app.font_small, (150, 150, 190))
        if self.mode == "campaign":
            text_center(app, surf, "CLEAR A LEVEL TO UNLOCK THE NEXT ONE", 122, app.font_small, NEON_YELLOW)


class Settings:
    music = "menu"
    layout = "field"
    field_x = FIELD_X
    ITEMS = ["RESOLUTION", "FULLSCREEN", "MUSIC VOLUME", "SOUND VOLUME", "BACK"]

    def __init__(self, app):
        self.app = app
        self.sel = 0

    def row_rect(self, i):
        return pygame.Rect(W // 2 - 300, 200 + i * 80, 600, 60)

    def value_text(self, item):
        s = self.app.settings
        if item == "RESOLUTION":
            w, h = self.app.current_resolution()
            return "DESKTOP" if s["fullscreen"] else f"{w} x {h}"
        if item == "FULLSCREEN":
            return "ON" if s["fullscreen"] else "OFF"
        if item == "MUSIC VOLUME":
            return f"{int(round(s['music'] * 100))}%"
        if item == "SOUND VOLUME":
            return f"{int(round(s['sfx'] * 100))}%"
        return ""

    def change(self, item, d):
        app, s = self.app, self.app.settings
        if item == "RESOLUTION":
            if s["fullscreen"]:
                return
            res = app.available_resolutions()
            cur = app.current_resolution()
            i = res.index(cur) if cur in res else 0
            s["resolution"] = list(res[(i + d) % len(res)])
            app.apply_display()
        elif item == "FULLSCREEN":
            s["fullscreen"] = not s["fullscreen"]
            app.apply_display()
        elif item == "MUSIC VOLUME":
            s["music"] = round(clamp(s["music"] + 0.1 * d, 0, 1), 2)
            app.audio.update_volume()
        elif item == "SOUND VOLUME":
            s["sfx"] = round(clamp(s["sfx"] + 0.1 * d, 0, 1), 2)
        save_settings(s)
        app.audio.play("pong_paddle")

    def back(self):
        save_settings(self.app.settings)
        self.app.scene = Menu(self.app, sel=3)

    def handle_event(self, e):
        item = self.ITEMS[self.sel]
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.back()
            elif e.key in (pygame.K_UP, pygame.K_w):
                self.sel = (self.sel - 1) % len(self.ITEMS)
            elif e.key in (pygame.K_DOWN, pygame.K_s):
                self.sel = (self.sel + 1) % len(self.ITEMS)
            elif e.key in (pygame.K_LEFT, pygame.K_a) and item != "BACK":
                self.change(item, -1)
            elif e.key in (pygame.K_RIGHT, pygame.K_d) and item != "BACK":
                self.change(item, 1)
            elif e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                if item == "BACK":
                    self.back()
                else:
                    self.change(item, 1)
        elif e.type == pygame.MOUSEMOTION:
            for i in range(len(self.ITEMS)):
                if self.row_rect(i).collidepoint(e.pos):
                    self.sel = i
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for i, it in enumerate(self.ITEMS):
                r = self.row_rect(i)
                if r.collidepoint(e.pos):
                    self.sel = i
                    if it == "BACK":
                        self.back()
                    else:
                        self.change(it, -1 if e.pos[0] < r.x + 380 else 1)

    def update(self, dt):
        pass

    def draw(self, surf):
        app = self.app
        surf.blit(app.bg, (0, 0))
        neon_text(surf, "SETTINGS", app.font_huge, (W // 2, 100), glitch=False, split=2)
        for i, item in enumerate(self.ITEMS):
            r = self.row_rect(i)
            on = i == self.sel
            if item == "BACK":
                draw_button(app, surf, pygame.Rect(W // 2 - 120, r.y, 240, 56), "BACK", on)
                continue
            pygame.draw.rect(surf, (50, 58, 120) if on else (26, 28, 56), r, border_radius=10)
            pygame.draw.rect(surf, (140, 170, 255) if on else (70, 75, 120), r, 2, border_radius=10)
            surf.blit(app.font_bold.render(item, True, (230, 230, 250)), (r.x + 20, r.y + 20))
            disabled = item == "RESOLUTION" and app.settings["fullscreen"]
            col = (255, 230, 120) if on and not disabled else (180, 180, 210)
            text_center(app, surf, "<", r.centery, app.font_big, col, r.x + 300)
            text_center(app, surf, ">", r.centery, app.font_big, col, r.right - 30)
            val = self.value_text(item)
            if item in ("MUSIC VOLUME", "SOUND VOLUME"):
                frac = app.settings["music" if item == "MUSIC VOLUME" else "sfx"]
                bar = pygame.Rect(r.x + 325, r.centery - 6, 170, 12)
                pygame.draw.rect(surf, (20, 20, 40), bar, border_radius=6)
                pygame.draw.rect(surf, (120, 200, 255), (bar.x, bar.y, int(bar.w * frac), bar.h), border_radius=6)
                text_center(app, surf, val, r.centery, app.font_small_bold, (255, 255, 255), r.right - 70)
            else:
                text_center(app, surf, val, r.centery, app.font_bold, col, r.x + 432)
        text_center(app, surf, "Up / Down to choose  -  Left / Right to change  -  Esc to go back", 690,
                    app.font_small, (150, 150, 190))


class Game:
    music = "game"
    layout = "full"
    field_x = PANEL_W

    def __init__(self, app, levels, start=0, campaign=False, builder=None):
        self.app = app
        self.levels = levels
        self.campaign = campaign
        self.builder = builder
        self.level_idx = start
        self.score = 0
        self.lives = 3
        self.t = 0.0
        self.shake_offset = (0, 0)
        self.load_level()

    # ---------- setup ----------
    @property
    def test_mode(self):
        return self.builder is not None

    def load_level(self):
        if self.app.witch:
            self.app.witch.set_mode("idle")
        name, grid = self.levels[self.level_idx]
        self.grid = [row[:] for row in grid]
        self.level_name = name
        self.speed = START_SPEED
        self.particles = []
        self.texts = []
        self.shake = 0.0
        self.flash = 0.0
        self.banner = 2.2
        self.state = "play"   # play | paused | dead | cleared | won
        self.state_t = 0.0
        self.reset_round()

    def reset_round(self):
        self.paddle_x = W / 2
        self.effects = {}
        self.powerups = []
        self.lasers = []
        self.laser_cd = 0.0
        self.split_next = False
        self.balls = [Ball(self.paddle_x, PADDLE_Y - BALL_R - 1, stuck=True)]
        self.use_mouse = False

    # ---------- derived values ----------
    @property
    def paddle_w(self):
        return BASE_PADDLE_W * (1.5 if "WIDE" in self.effects else 1.0)

    @property
    def paddle_speed(self):
        return 900 * (2.0 if "TURBO" in self.effects else 1.0)

    @property
    def ball_speed(self):
        return self.speed * (1.4 if "FAST" in self.effects else 1.0)

    @property
    def multiplier(self):
        m = 1
        if "FAST" in self.effects:
            m *= 2
        if "RUSH" in self.effects:
            m *= 3
        return m

    def paddle_rect(self):
        w = self.paddle_w
        return pygame.Rect(int(self.paddle_x - w / 2), PADDLE_Y, int(w), PADDLE_H)

    def sfx(self, name, vol=1.0):
        self.app.audio.play(name, vol)

    # ---------- input ----------
    def leave(self):
        if self.test_mode:
            self.app.scene = self.builder
        else:
            self.app.scene = LevelSelect(self.app, "campaign" if self.campaign else "custom")

    def launch(self):
        launched = False
        for b in self.balls:
            if b.stuck:
                b.stuck = False
                launched = True
                a = math.radians(random.uniform(-25, 25))
                b.vx, b.vy = math.sin(a) * self.ball_speed, -math.cos(a) * self.ball_speed
        if launched:
            self.sfx("pong_paddle")

    def handle_event(self, e):
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_ESCAPE:
                self.leave()
            elif e.key == pygame.K_p and self.state in ("play", "paused"):
                self.state = "paused" if self.state == "play" else "play"
                if self.app.audio.ok:
                    (pygame.mixer.music.pause if self.state == "paused" else pygame.mixer.music.unpause)()
            elif e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d):
                self.use_mouse = False
            elif e.key in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                self.on_confirm(e.key == pygame.K_SPACE)
        elif e.type == pygame.MOUSEMOTION:
            self.use_mouse = True
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.on_confirm(True)

    def on_confirm(self, is_action):
        if self.state == "play":
            if is_action:
                self.launch()
        elif self.state == "dead":
            if self.test_mode:
                self.leave()
            else:
                self.score, self.lives = 0, 3
                self.load_level()
        elif self.state == "cleared" and self.state_t > 0.6:
            self.next_level()
        elif self.state == "won" and self.state_t > 0.6:
            if self.campaign and not self.test_mode and self.level_idx == len(CAMPAIGN) - 1:
                self.app.scene = Ending(self.app, self.score)
            else:
                self.leave()

    def next_level(self):
        if self.test_mode:
            self.leave()
            return
        self.level_idx += 1
        self.load_level()

    # ---------- effects ----------
    def burst(self, x, y, color, n=14, speed=240, size=4, life=0.7):
        for _ in range(n):
            self.particles.append(Particle(x, y, color, speed, size, life))

    def float_text(self, text, x, y, color):
        while any(abs(t[2] - y) < 24 and abs(t[1] - x) < 160 for t in self.texts):
            y -= 26
        self.texts.append([text, clamp(x, 110, W - 110), y, color, 1.2])

    # ---------- bricks ----------
    def hit_tile(self, c, r, smash=False):
        v = self.grid[r][c]
        rect = tile_rect(c, r)
        if v == WALL:
            self.sfx("clank", 0.6)
            self.burst(rect.centerx, rect.centery, (200, 200, 220), n=4, speed=120, size=2, life=0.3)
            return
        if v == BOMB:
            self.explode(c, r)
            return
        if v in (1, 2, 3):
            v = 0 if smash else v - 1
            self.score += 10 * self.multiplier
            if v == 0:
                self.destroy(c, r, BRICK_COLORS[self.grid[r][c]])
            else:
                self.grid[r][c] = v
                self.sfx("crack")
                self.burst(rect.centerx, rect.centery, BRICK_COLORS[v + 1], n=5, speed=140, size=3, life=0.35)

    def destroy(self, c, r, color):
        self.grid[r][c] = EMPTY
        rect = tile_rect(c, r)
        self.sfx("break")
        self.burst(rect.centerx, rect.centery, color)
        self.score += 40 * self.multiplier
        self.speed = min(self.speed + 3, MAX_SPEED)
        if random.random() < DROP_CHANCE:
            kinds, weights = zip(*POWERUP_WEIGHTS.items())
            self.powerups.append(PowerUp(rect.centerx, rect.centery, random.choices(kinds, weights)[0]))

    def explode(self, c, r):
        self.grid[r][c] = EMPTY
        rect = tile_rect(c, r)
        self.sfx("boom")
        self.shake = max(self.shake, 0.35)
        self.flash = max(self.flash, 0.12)
        self.burst(rect.centerx, rect.centery, (255, 220, 80), n=30, speed=420, size=5, life=0.9)
        self.burst(rect.centerx, rect.centery, BOMB_COLOR, n=20, speed=300, size=4, life=0.8)
        self.score += 60 * self.multiplier
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if 0 <= rr < ROWS and 0 <= cc < COLS:
                    v = self.grid[rr][cc]
                    if v == BOMB:
                        self.explode(cc, rr)
                    elif v in (1, 2, 3):
                        self.destroy(cc, rr, BRICK_COLORS[v])

    # ---------- power-ups ----------
    def apply_powerup(self, kind):
        p = POWERUPS[kind]
        self.sfx("powerup")
        self.float_text(p["label"], self.paddle_x, PADDLE_Y - 30, p["color"])
        self.burst(self.paddle_x, PADDLE_Y, p["color"], n=20, speed=260, size=3)
        self.score += 25 * self.multiplier
        if self.app.hero and kind in ("MULTI", "LIFE"):
            self.app.hero.trigger(kind)
        if kind == "MULTI":
            if all(b.stuck for b in self.balls):
                self.launch()
                self.split_next = True
            else:
                self.split_balls()
        elif kind == "LIFE":
            self.lives += 1
        else:
            self.effects[kind] = p["dur"]

    def split_balls(self):
        new = []
        for b in self.balls:
            if b.stuck:
                continue
            ang = math.atan2(b.vx, -b.vy)
            for d in (-0.45, 0.45):
                a = ang + d
                new.append(Ball(b.x, b.y, math.sin(a) * self.ball_speed, -abs(math.cos(a)) * self.ball_speed))
        self.balls.extend(new[: max(0, 15 - len(self.balls))])

    # ---------- physics ----------
    def normalize(self, b):
        sp = self.ball_speed
        mag = math.hypot(b.vx, b.vy) or 1.0
        b.vx, b.vy = b.vx / mag * sp, b.vy / mag * sp
        min_vy = 0.28 * sp   # never let the ball go (almost) horizontal
        if abs(b.vy) < min_vy:
            b.vy = math.copysign(min_vy, b.vy if b.vy else -1)
            b.vx = math.copysign(math.sqrt(max(sp * sp - min_vy * min_vy, 0)), b.vx if b.vx else 1)

    def collide_grid(self, b):
        c0 = int((b.x - BALL_R) // TILE_W)
        c1 = int((b.x + BALL_R) // TILE_W)
        r0 = int((b.y - BALL_R - GRID_TOP) // TILE_H)
        r1 = int((b.y + BALL_R - GRID_TOP) // TILE_H)
        fire = "FIRE" in self.effects
        best = None
        for r in range(max(r0, 0), min(r1, ROWS - 1) + 1):
            for c in range(max(c0, 0), min(c1, COLS - 1) + 1):
                v = self.grid[r][c]
                if v == EMPTY:
                    continue
                rect = tile_rect(c, r)
                cx = clamp(b.x, rect.left, rect.right)
                cy = clamp(b.y, rect.top, rect.bottom)
                dx, dy = b.x - cx, b.y - cy
                d2 = dx * dx + dy * dy
                if d2 >= BALL_R * BALL_R:
                    continue
                if fire and v in (1, 2, 3):
                    self.hit_tile(c, r, smash=True)
                    continue
                if best is None or d2 < best[0]:
                    best = (d2, c, r, cx, cy, dx, dy)
        if best:
            d2, c, r, cx, cy, dx, dy = best
            d = math.sqrt(d2)
            if d < 1e-6:
                mag = math.hypot(b.vx, b.vy) or 1
                nx, ny = -b.vx / mag, -b.vy / mag
            else:
                nx, ny = dx / d, dy / d
            b.x, b.y = cx + nx * BALL_R, cy + ny * BALL_R
            dot = b.vx * nx + b.vy * ny
            if dot < 0:
                b.vx -= 2 * dot * nx
                b.vy -= 2 * dot * ny
            self.sfx("pong_wall" if self.grid[r][c] == WALL else "pong_brick")
            self.hit_tile(c, r)
            self.normalize(b)

    def step_ball(self, b, dt):
        b.x += b.vx * dt
        b.y += b.vy * dt
        bounced = False
        if b.x < BALL_R:
            b.x, b.vx, bounced = BALL_R, abs(b.vx), True
        elif b.x > W - BALL_R:
            b.x, b.vx, bounced = W - BALL_R, -abs(b.vx), True
        if b.y < HUD_H + BALL_R:
            b.y, b.vy, bounced = HUD_H + BALL_R, abs(b.vy), True
        if bounced:
            self.sfx("pong_wall", 0.8)
        if GRID_TOP - BALL_R < b.y < GRID_BOTTOM + BALL_R:
            self.collide_grid(b)
        w = self.paddle_w
        if (b.vy > 0 and PADDLE_Y - BALL_R <= b.y <= PADDLE_Y + PADDLE_H
                and self.paddle_x - w / 2 - BALL_R <= b.x <= self.paddle_x + w / 2 + BALL_R):
            off = clamp((b.x - self.paddle_x) / (w / 2), -1, 1)
            a = math.radians(off * 62)
            sp = self.ball_speed
            b.vx, b.vy = math.sin(a) * sp, -math.cos(a) * sp
            b.y = PADDLE_Y - BALL_R
            self.sfx("pong_paddle")
            self.burst(b.x, PADDLE_Y, (200, 220, 255), n=5, speed=120, size=2, life=0.3)
        if b.y > H + BALL_R:
            b.dead = True

    def update_characters(self, dt):
        hero, witch = self.app.hero, self.app.witch
        if hero and self.state != "paused":
            if self.state == "play":
                fx = self.effects
            elif self.state in ("cleared", "won"):
                fx = {"RUSH": 1, "FIRE": 1}            # victory: he goes wild
            else:
                fx = {}
            hero.update(dt, fx)
        if witch and self.state == "dead":
            witch.update(dt)

    def update(self, dt):
        self.t += dt
        self.state_t += dt
        self.update_characters(dt)
        self.banner = max(0.0, self.banner - dt)
        self.shake = max(0.0, self.shake - dt)
        self.flash = max(0.0, self.flash - dt)
        self.update_particles(dt)
        if self.state == "cleared" and self.state_t > 2.5:
            self.next_level()
        if self.state != "play":
            return

        for k in list(self.effects):
            self.effects[k] -= dt
            if self.effects[k] <= 0:
                del self.effects[k]

        gdt = dt * (1.4 if "RUSH" in self.effects else 1.0)

        keys = pygame.key.get_pressed()
        move = (keys[pygame.K_RIGHT] or keys[pygame.K_d]) - (keys[pygame.K_LEFT] or keys[pygame.K_a])
        maxstep = self.paddle_speed * gdt
        if move:
            self.paddle_x += move * maxstep
        elif self.use_mouse:
            mx = self.app.mouse_pos()[0]
            self.paddle_x += clamp(mx - self.paddle_x, -maxstep, maxstep)
        half = self.paddle_w / 2
        self.paddle_x = clamp(self.paddle_x, half, W - half)

        # lasers
        self.laser_cd -= gdt
        firing = keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]
        if "LASER" in self.effects and firing and self.laser_cd <= 0 and not any(b.stuck for b in self.balls):
            self.laser_cd = 0.22
            self.sfx("laser")
            for x in (self.paddle_x - half + 8, self.paddle_x + half - 8):
                self.lasers.append([x, PADDLE_Y - 4])
        for L in self.lasers:
            L[1] -= 950 * gdt
            r = int((L[1] - GRID_TOP) // TILE_H)
            c = int(L[0] // TILE_W)
            if 0 <= r < ROWS and 0 <= c < COLS and self.grid[r][c] != EMPTY:
                self.hit_tile(c, r)
                L[1] = -100
        self.lasers = [L for L in self.lasers if L[1] > HUD_H]

        # balls
        if self.split_next:
            self.split_next = False
            self.split_balls()
        for b in self.balls:
            if b.stuck:
                b.x = self.paddle_x + b.offset
                b.y = PADDLE_Y - BALL_R - 1
                continue
            self.normalize(b)
            dist = self.ball_speed * gdt
            steps = int(dist / 4) + 1
            for _ in range(steps):
                self.step_ball(b, gdt / steps)
                if b.dead:
                    break
            b.trail.append((b.x, b.y))
            if len(b.trail) > 10:
                b.trail.pop(0)
        self.balls = [b for b in self.balls if not b.dead]
        if not self.balls:
            if not self.test_mode:
                self.lives -= 1
            self.sfx("lose")
            self.shake = 0.3
            if self.lives <= 0:
                self.state, self.state_t = "dead", 0.0
                if self.app.witch:
                    self.app.witch.set_mode("laugh")
            else:
                self.reset_round()
            return

        # falling power-ups
        pr = self.paddle_rect()
        for p in self.powerups:
            p.y += 170 * gdt
        caught = [p for p in self.powerups if p.rect.colliderect(pr)]
        for p in caught:
            self.apply_powerup(p.kind)
        self.powerups = [p for p in self.powerups if p not in caught and p.y < H + 20]

        if not has_breakables(self.grid):
            self.level_cleared()

    def level_cleared(self):
        self.state, self.state_t = "cleared", 0.0
        self.score += 500
        self.sfx("clear")
        for _ in range(6):
            self.burst(random.uniform(100, W - 100), random.uniform(150, 450),
                       random.choice(list(BRICK_COLORS.values())), n=25, speed=350)
        if self.campaign:
            s = self.app.settings
            s["unlocked"] = max(int(s.get("unlocked", 1)), min(self.level_idx + 2, len(CAMPAIGN)))
            save_settings(s)
        if self.test_mode or self.level_idx + 1 >= len(self.levels):
            self.state = "won"

    def update_particles(self, dt):
        for p in self.particles:
            p.life -= dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 500 * dt
            p.vx *= 0.98
        self.particles = [p for p in self.particles if p.life > 0]
        for t in self.texts:
            t[2] -= 40 * dt
            t[4] -= dt
        self.texts = [t for t in self.texts if t[4] > 0]

    # ---------- drawing ----------
    def draw(self, canvas):
        app = self.app
        self.draw_field(app.field)
        self.draw_panel(canvas)
        canvas.blit(app.field, (PANEL_W, 0))
        pygame.draw.line(canvas, NEON_CYAN, (PANEL_W, 0), (PANEL_W, H), 2)
        pygame.draw.line(canvas, NEON_PINK, (PANEL_W + 3, 0), (PANEL_W + 3, H), 1)
        if self.state == "dead":
            self.draw_game_over(canvas)

    def draw_panel(self, canvas):
        app = self.app
        rect = pygame.Rect(0, 0, PANEL_W, H)
        low = app.stage_panel.copy()
        lw, lh = low.get_size()
        cols = [POWERUPS[e]["color"] for e in self.effects if e in POWERUPS] if self.state == "play" else []
        if self.state in ("cleared", "won"):
            cols = [POWERUPS["RUSH"]["color"], POWERUPS["FIRE"]["color"]]
        cols = cols or [(255, 240, 200)]
        layer = pygame.Surface((lw, lh), pygame.SRCALPHA)
        for i in range(3):                                         # spotlights in the power-up colours
            col = cols[i % len(cols)]
            sx = 18 + i * 34
            sw = math.sin(self.t * 1.2 + i * 1.9) * 22
            pygame.draw.polygon(layer, col + (38,), [(sx - 2, 0), (sx + 2, 0), (sx + sw + 16, lh - 16), (sx + sw - 16, lh - 16)])
        low.blit(layer, (0, 0))
        canvas.blit(pygame.transform.scale(low, rect.size), rect.topleft)
        if app.hero:
            app.hero.draw(canvas, rect, 3, foot=(150, H - 40))
            label = "HEADBANGING!" if app.hero.headbanging else "TEMPO"
            col = NEON_YELLOW if app.hero.headbanging else NEON_CYAN
            text_center(app, canvas, label, 24, app.font_small, col, PANEL_W // 2)
            text_center(app, canvas, f"x{app.hero.speed:.2f}", 46, app.font_bold, (255, 255, 255), PANEL_W // 2)

    def draw_game_over(self, canvas):
        app = self.app
        field = pygame.Rect(PANEL_W, 0, W, H)
        if app.witch:
            app.witch.draw(canvas, field, 4, foot=(int(W * 0.72), H - 40))
        k = min(1.0, self.state_t / 0.8)
        neon_text(canvas, "GAME", app.font_huge, (PANEL_W + 250, 250), color=(255, 40, 90), t=self.t, split=int(3 * k))
        neon_text(canvas, "OVER", app.font_huge, (PANEL_W + 250, 330), color=(255, 40, 90), t=self.t + 1.3, split=int(3 * k))
        if self.state_t > 1.2 and int(self.state_t * 2) % 2 == 0:
            sub = "ENTER - BACK TO THE BUILDER" if self.test_mode else "ENTER - TRY AGAIN"
            text_center(app, canvas, sub, 430, app.font, (230, 210, 250), PANEL_W + 250)
            if not self.test_mode:
                text_center(app, canvas, "ESC - LEVEL SELECT", 462, app.font_small, (170, 150, 210), PANEL_W + 250)

    def draw_field(self, surf):
        app = self.app
        surf.blit(app.bg, (0, 0))

        for r in range(ROWS):
            for c in range(COLS):
                v = self.grid[r][c]
                if v:
                    draw_tile(surf, v, tile_rect(c, r), self.t)

        for p in self.powerups:
            info = POWERUPS[p.kind]
            rect = p.rect
            glow = 0.5 + 0.5 * math.sin(self.t * 8 + p.x)
            pygame.draw.rect(surf, darken(info["color"], 0.5), rect, border_radius=10)
            pygame.draw.rect(surf, lighten(info["color"], 0.3 * glow), rect.inflate(-4, -4), border_radius=8)
            txt = app.font_small_bold.render(info["short"], True, (20, 20, 30))
            surf.blit(txt, txt.get_rect(center=rect.center))

        for x, y in self.lasers:
            pygame.draw.line(surf, (255, 120, 230), (x, y), (x, y + 16), 4)
            pygame.draw.line(surf, (255, 255, 255), (x, y), (x, y + 16), 2)

        pr = self.paddle_rect()
        pcol = (0, 225, 255) if "TURBO" in self.effects else (230, 230, 250)
        if "TURBO" in self.effects:
            for i in range(1, 4):
                ghost = pr.move(0, i * 3).inflate(-i * 10, 0)
                pygame.draw.rect(surf, darken(pcol, 0.4 + i * 0.15), ghost, border_radius=7)
        pygame.draw.rect(surf, darken(pcol, 0.4), pr, border_radius=7)
        pygame.draw.rect(surf, pcol, pr.inflate(-3, -4).move(0, -1), border_radius=7)
        if "LASER" in self.effects:
            for x in (pr.left + 8, pr.right - 8):
                pygame.draw.rect(surf, (255, 60, 200), (x - 4, pr.top - 7, 8, 10), border_radius=2)

        fire = "FIRE" in self.effects
        for b in self.balls:
            base = (255, 140, 30) if fire else (255, 90, 90) if "FAST" in self.effects else (255, 255, 255)
            n = len(b.trail)
            for i, (tx, ty) in enumerate(b.trail):
                k = (i + 1) / (n + 1)
                pygame.draw.circle(surf, darken(base, 1 - k * 0.6), (int(tx), int(ty)), max(1, int(BALL_R * k * 0.8)))
            if fire:
                pygame.draw.circle(surf, (255, 200, 60), (int(b.x), int(b.y)), BALL_R + 3)
            pygame.draw.circle(surf, base, (int(b.x), int(b.y)), BALL_R)
            pygame.draw.circle(surf, (255, 255, 255), (int(b.x - 2), int(b.y - 2)), 3)

        for p in self.particles:
            k = p.life / p.max_life
            s = max(1, int(p.size * k + 0.5))
            surf.fill(p.color, (int(p.x), int(p.y), s, s))
        for text, x, y, col, life in self.texts:
            img = app.font_bold.render(text, True, col)
            img.set_alpha(int(255 * min(1, life)))
            surf.blit(img, img.get_rect(center=(x, y)))

        self.draw_hud(surf)

        if self.flash > 0:
            fl = pygame.Surface((W, H))
            fl.fill((255, 240, 200))
            fl.set_alpha(int(180 * self.flash / 0.12))
            surf.blit(fl, (0, 0))

        if self.banner > 0 and self.state == "play":
            img = app.font_huge.render(self.level_name, True, (255, 240, 200))
            img.set_alpha(int(255 * min(1, self.banner)))
            surf.blit(img, img.get_rect(center=(W // 2, 560)))
        elif any(b.stuck for b in self.balls) and self.state == "play":
            text_center(app, surf, "SPACE / CLICK TO LAUNCH", 560, app.font, NEON_CYAN)
        if self.state == "paused":
            self.overlay(surf, "PAUSED", "P - CONTINUE    ESC - QUIT")
        elif self.state == "dead":
            shade = pygame.Surface((W, H), pygame.SRCALPHA)
            shade.fill((10, 0, 20, 120))
            surf.blit(shade, (0, 0))
        elif self.state == "cleared":
            self.overlay(surf, "LEVEL CLEARED!", "+500 BONUS - ENTER TO CONTINUE")
        elif self.state == "won":
            if self.test_mode:
                self.overlay(surf, "LEVEL CLEARED!", "ENTER - BACK TO THE BUILDER")
            else:
                self.overlay(surf, "YOU WIN!", f"FINAL SCORE {self.score} - ENTER")

        ox = oy = 0
        if self.shake > 0:
            amp = 10 * self.shake
            ox, oy = random.uniform(-amp, amp), random.uniform(-amp, amp)
        self.shake_offset = (ox, oy)

    def draw_hud(self, surf):
        app = self.app
        pygame.draw.rect(surf, (14, 14, 30), (0, 0, W, HUD_H))
        pygame.draw.line(surf, NEON_PINK, (0, HUD_H), (W, HUD_H), 2)
        surf.blit(app.font_bold.render(f"SCORE {self.score}", True, (255, 255, 255)), (14, 18))
        mult = self.multiplier
        if mult > 1:
            surf.blit(app.font_bold.render(f"x{mult}", True, NEON_YELLOW), (196, 18))
        name = self.level_name
        while app.font_small_bold.size(name)[0] > 200 and len(name) > 4:
            name = name[:-4] + "..."
        surf.blit(app.font_small.render(name, True, NEON_CYAN), (245, 20))
        if self.test_mode:
            surf.blit(app.font_small.render("LIVES INF", True, (255, 255, 255)), (W - 110, 20))
        else:
            pygame.draw.circle(surf, (255, 255, 255), (W - 70, 25), 8)
            surf.blit(app.font_bold.render(f"x{self.lives}", True, (255, 255, 255)), (W - 56, 18))
        x = 460
        for k, rem in self.effects.items():
            info = POWERUPS[k]
            pygame.draw.rect(surf, darken(info["color"], 0.6), (x, 8, 64, 34), border_radius=6)
            lab = app.font_tiny.render(k, True, (255, 255, 255))
            surf.blit(lab, lab.get_rect(midtop=(x + 32, 11)))
            frac = clamp(rem / info["dur"], 0, 1)
            pygame.draw.rect(surf, info["color"], (x + 6, 30, int(52 * frac), 6), border_radius=3)
            x += 68

    def overlay(self, surf, title, sub):
        shade = pygame.Surface((W, H), pygame.SRCALPHA)
        shade.fill((0, 0, 10, 150))
        surf.blit(shade, (0, 0))
        neon_text(surf, title, self.app.font_huge, (W // 2, H // 2 - 30), t=self.t)
        text_center(self.app, surf, sub, H // 2 + 45, self.app.font, (220, 210, 240))



def make_sunset():
    """Low-res (1/2 scale, 640x360) synthwave sunset for the ending."""
    lw, lh = CW // 2, H // 2
    bg = pygame.Surface((lw, lh))
    hz = 220
    stops = [(0, (36, 14, 66)), (110, (150, 44, 120)), (180, (240, 100, 90)), (hz, (255, 196, 110))]
    for y in range(hz):
        for (y0, c0), (y1, c1) in zip(stops, stops[1:]):
            if y0 <= y <= y1:
                k = (y - y0) / max(1, y1 - y0)
                bg.fill(tuple(int(a + (b - a) * k) for a, b in zip(c0, c1)), (0, y, lw, 1))
    rnd = random.Random(11)
    for _ in range(40):                                        # first stars in the purple
        b = rnd.randrange(140, 230)
        bg.set_at((rnd.randrange(lw), rnd.randrange(80)), (b, b, 255))
    # the setting sun with synthwave stripes
    cx, cy, r = 440, hz - 6, 74
    for y in range(cy - r, hz):
        dy = y - cy
        if abs(dy) > r:
            continue
        half = int((r * r - dy * dy) ** 0.5)
        k = (y - (cy - r)) / (2 * r)
        col = (255, int(236 - 140 * k), int(120 - 30 * k))
        if y > cy - 30 and (y - (cy - 30)) % 9 < (y - (cy - 30)) // 9 + 1:
            continue                                           # the gaps get thicker towards the horizon
        bg.fill(col, (cx - half, y, half * 2, 1))
    # mountains
    for layer, (col, base, amp, seed) in enumerate((((96, 34, 92), hz, 46, 5), ((52, 18, 58), hz, 26, 9))):
        rr = random.Random(seed)
        pts = [(0, base)]
        x = 0
        while x < lw:
            x += rr.randint(18, 46)
            pts.append((x, base - rr.randint(4, amp)))
        pts += [(lw, base), (lw, base + 1), (0, base + 1)]
        pygame.draw.polygon(bg, col, pts)
    # neon grid ground
    for y in range(hz, lh):
        k = (y - hz) / (lh - hz)
        bg.fill((int(46 - 26 * k), int(14 - 6 * k), int(56 - 26 * k)), (0, y, lw, 1))
    vp = (lw // 2, hz)
    for i in range(-14, 15):
        pygame.draw.line(bg, (170, 40, 160), vp, (vp[0] + i * 60, lh), 1)
    y, gap = hz + 3, 3
    while y < lh:
        pygame.draw.line(bg, (190, 50, 170), (0, y), (lw, y), 1)
        gap = int(gap * 1.35) + 1
        y += gap
    pygame.draw.line(bg, (255, 120, 200), (0, hz), (lw, hz), 1)
    return bg


def star_points(cx, cy, r1, r2, n=8, rot=0.0):
    pts = []
    for i in range(n * 2):
        r = r1 if i % 2 == 0 else r2
        a = rot + i * math.pi / n
        pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
    return pts


class Ending:
    """Reward for clearing the campaign: the rocker smacks the witch into orbit,
    then rests on his green coupe at sunset while she sticks out of the ground, steaming."""
    layout = "full"
    field_x = 0
    PART_B = 8.6
    WALK_END, WIND_END, HIT_END, FLY_END = 1.6, 2.35, 2.75, 5.0

    def __init__(self, app, score=0):
        self.app = app
        self.score = score
        self.t = 0.0
        d = os.path.join(ASSETS, "sprites", "ending")
        load = lambda n: pygame.image.load(os.path.join(d, n)).convert_alpha()
        self.img = {n: load(n + ".png") for n in ("hero_windup", "hero_strike", "hero_sit", "guitar_lean",
                                                   "witch_shock", "witch_stuck", "car")}
        self.shock = pygame.transform.flip(self.img["witch_shock"], True, False)
        self.sunset = make_sunset()
        self.parts = []
        self.flash = 0.0
        self.shake = 0.0
        self.shake_offset = (0, 0)
        self.fired = set()
        if app.witch:
            app.witch.set_mode("idle")

    @property
    def music(self):
        return "menu" if self.t >= self.PART_B else "game"

    def handle_event(self, e):
        go = (e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER)) or \
             (e.type == pygame.MOUSEBUTTONDOWN and e.button == 1)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            self.app.scene = Menu(self.app)
        elif go:
            if self.t < self.PART_B:
                self.t = self.PART_B          # skip to the sunset
                self.parts.clear()
            elif self.t > self.PART_B + 1.5:
                self.app.scene = Menu(self.app)

    def once(self, key, fn):
        if key not in self.fired:
            self.fired.add(key)
            fn()

    # positions in the 1/3-scale night scene
    WITCH_FOOT = (300, 214)
    HERO_X = 209

    def witch_fly(self):
        p = clamp((self.t - self.HIT_END) / (self.FLY_END - self.HIT_END), 0, 1)
        x = self.WITCH_FOOT[0] + 125 * p
        y = self.WITCH_FOOT[1] - 70 - 140 * p + 40 * p * p
        return p, x, y

    def update(self, dt):
        self.t += dt
        t = self.t
        app = self.app
        self.flash = max(0.0, self.flash - dt)
        self.shake = max(0.0, self.shake - dt)
        if t < self.PART_B:
            if app.hero:
                if t < self.WALK_END:
                    app.hero.update(dt, {})
                elif t > self.HIT_END + 0.5:
                    app.hero.update(dt, {"FIRE": 1, "RUSH": 1})          # victory headbang
            if app.witch and t < self.WIND_END:
                app.witch.update(dt)
            if t >= self.WIND_END:
                def hit():
                    self.flash, self.shake = 0.15, 0.45
                    app.audio.play("boom")
                    app.audio.play("pong_paddle")
                    ix, iy = self.impact()
                    for _ in range(40):
                        a = random.uniform(0, math.tau)
                        sp = random.uniform(40, 160)
                        self.parts.append(["spark", ix, iy, math.cos(a) * sp, math.sin(a) * sp, 0.6,
                                           random.choice((NEON_YELLOW, (255, 255, 255), (255, 120, 60)))])
                self.once("hit", hit)
            if self.HIT_END <= t < self.FLY_END:
                p, x, y = self.witch_fly()
                s = 1 - 0.9 * p
                if random.random() < dt * 40:                       # steam pouring off her behind
                    self.parts.append(["steam", x - 14 * s, y + 18 * s, random.uniform(-30, -10),
                                       random.uniform(-10, 10), 0.8, None])
                self.once("whoosh", lambda: app.audio.play("laser", 0.7))
            if t >= self.FLY_END:
                self.once("ding", lambda: app.audio.play("powerup"))
        else:
            self.once("sunset", lambda: self.parts.clear())
            # cigarette smoke and witch steam (1/2-scale sunset coordinates)
            if random.random() < dt * 6:
                self.parts.append(["smoke", 363, 218, random.uniform(-3, 3), -12, 3.0, None])
            if random.random() < dt * 10:
                self.parts.append(["steam2", 556 + random.uniform(-6, 6), 270, random.uniform(-4, 4), -16, 1.8, None])
        for p in self.parts:
            p[5] -= dt
            p[1] += p[3] * dt
            p[2] += p[4] * dt
            if p[0] == "smoke":
                p[3] = math.sin(self.t * 1.3 + p[2] * 0.08) * 6 + 3
            elif p[0] == "spark":
                p[4] += 200 * dt
        self.parts = [p for p in self.parts if p[5] > 0]

    def impact(self):
        ox = self.HERO_X - 88
        oy = 214 - 158
        return ox + 164, oy + 98

    # ------------------------------------------------------------------ drawing
    def draw(self, canvas):
        if self.t < self.PART_B:
            self.draw_smack(canvas)
        else:
            self.draw_sunset(canvas)
        if self.shake > 0:
            a = 12 * self.shake
            self.shake_offset = (random.uniform(-a, a), random.uniform(-a, a))
        else:
            self.shake_offset = (0, 0)

    def draw_smack(self, canvas):
        app, t = self.app, self.t
        canvas.blit(app.night, (0, 0))
        low = pygame.Surface((CW // 3, H // 3), pygame.SRCALPHA)
        wx, wy = self.WITCH_FOOT
        # the witch: turned away, gloating ... then launched
        if t < self.WIND_END and app.witch:
            frame, _ = app.witch.current()
            low.blit(pygame.transform.flip(frame, True, False), (wx - 48, wy - 142))
        elif t < self.HIT_END:
            low.blit(self.shock, (wx - 48 + random.randint(-1, 1), wy - 142))
        elif t < self.FLY_END:
            p, x, y = self.witch_fly()
            s = max(0.05, 1 - 0.95 * p)
            img = pygame.transform.scale(self.shock, (max(1, int(96 * s)), max(1, int(144 * s))))
            img = pygame.transform.rotate(img, -720 * p)
            low.blit(img, img.get_rect(center=(x, y)))
        else:
            k = (t - self.FLY_END) / 0.7
            if k < 1:
                _, x, y = 1, wx + 125, wy - 70 - 140 + 40
                r = 10 * math.sin(k * math.pi)
                pygame.draw.polygon(low, (255, 255, 230), star_points(x, y, r, r * 0.3, 4, k * 3))
        # the rocker
        hx = self.HERO_X
        if t < self.WALK_END:
            if app.hero:
                k = t / self.WALK_END
                fx = -40 + (hx - 4 + 40) * k
                frames = app.hero.cycles["play"]["frames"]
                low.blit(frames[int(t * 10) % len(frames)], (fx - 48, 214 - 142 + (int(t * 10) % 2)))
        elif t < self.WIND_END:
            low.blit(self.img["hero_windup"], (hx - 88, 214 - 158))
        elif t < self.HIT_END + 0.5:
            low.blit(self.img["hero_strike"], (hx - 88, 214 - 158))
        elif app.hero:
            app.hero.draw(canvas, canvas.get_rect(), 3, foot=(hx * 3, 214 * 3 + 6))
        # particles
        for p in self.parts:
            if p[0] == "spark":
                low.fill(p[6], (int(p[1]), int(p[2]), 2, 2))
            elif p[0] == "steam":
                a = int(200 * p[5] / 0.8)
                pygame.draw.circle(low, (240, 240, 250, a), (int(p[1]), int(p[2])), int(2 + (0.8 - p[5]) * 6))
        canvas.blit(pygame.transform.scale(low, (CW, H)), (0, 0))
        # comic "SMACK!" burst
        if self.WIND_END <= t < self.WIND_END + 1.1:
            ix, iy = self.impact()
            k = min(1.0, (t - self.WIND_END) / 0.12)
            cx, cy = ix * 3 + 40, iy * 3 - 70
            pygame.draw.polygon(canvas, (255, 60, 40), star_points(cx, cy, 120 * k, 70 * k, 12, 0.2))
            pygame.draw.polygon(canvas, NEON_YELLOW, star_points(cx, cy, 100 * k, 58 * k, 12, 0.2))
            if k >= 1:
                neon_text(canvas, "SMACK!", app.font_huge, (cx, cy), color=(255, 40, 40), core=(255, 255, 255),
                          glitch=False, split=3)
        if self.t > self.HIT_END + 0.6:
            neon_text(canvas, "AND STAY OUT OF MY NIGHT!", app.font_big, (CW // 2, 70), color=NEON_CYAN,
                      t=self.t, glitch=False, split=2)
        # flash and fade to black
        if self.flash > 0:
            fl = pygame.Surface((CW, H))
            fl.fill((255, 255, 255))
            fl.set_alpha(int(255 * self.flash / 0.15))
            canvas.blit(fl, (0, 0))
        fade_start = self.FLY_END + 0.9
        if t > fade_start:
            k = min(1.0, (t - fade_start) / 0.7)
            sh = pygame.Surface((CW, H))
            sh.set_alpha(int(255 * k))
            canvas.blit(sh, (0, 0))
            if k >= 1:
                a = min(1.0, (t - fade_start - 0.7) / 0.4)
                if a > 0:
                    neon_text(canvas, "THE NEXT EVENING...", app.font_big, (CW // 2, H // 2), color=NEON_PINK,
                              t=t, glitch=False, split=int(2 * a))

    def draw_sunset(self, canvas):
        app, t = self.app, self.t - self.PART_B
        low = self.sunset.copy()
        im = self.img
        # long shadow under the car
        pygame.draw.ellipse(low, (20, 6, 30), (70, 322, 380, 16))
        low.blit(im["guitar_lean"], (22, 330 - 110))
        low.blit(im["car"], (60, 214))
        bob = 1 if int(t / 1.7) % 2 else 0                      # relaxed breathing
        low.blit(im["hero_sit"], (300, 190 + bob))
        low.blit(im["witch_stuck"], (518, 236))
        # glow of the red-hot patch
        g = pygame.Surface((40, 30), pygame.SRCALPHA)
        pygame.draw.ellipse(g, (255, 60, 40, int(70 + 40 * math.sin(t * 4))), g.get_rect())
        low.blit(g, (536, 254))
        for p in self.parts:
            f = p[5]
            if p[0] == "smoke":
                a = int(150 * min(1, f / 3.0))
                r = int(1 + (3.0 - f) * 2.2)
                pygame.draw.circle(low, (200, 196, 210, a), (int(p[1]), int(p[2])), r)
            elif p[0] == "steam2":
                a = int(210 * min(1, f / 1.8))
                r = int(2 + (1.8 - f) * 4)
                pygame.draw.circle(low, (245, 245, 255, a), (int(p[1]), int(p[2])), r)
        # ember glow
        if int(t * 3) % 3 != 0:
            low.fill((255, 200, 80), (362, 220 + bob, 1, 1))
        canvas.blit(pygame.transform.scale(low, (CW, H)), (0, 0))
        k = min(1.0, t / 0.8)
        if k < 1:
            sh = pygame.Surface((CW, H))
            sh.set_alpha(int(255 * (1 - k)))
            canvas.blit(sh, (0, 0))
        if t > 1.5:
            neon_text(canvas, "THE END", app.font_title, (CW // 2, 90), t=self.t)
        if t > 2.5:
            text_center(app, canvas, "THANKS FOR PLAYING  BREAKING NIGHT", 168, app.font, NEON_YELLOW, CW // 2)
            text_center(app, canvas, f"FINAL SCORE {self.score}", 196, app.font_small, (255, 255, 255), CW // 2)
        if t > 3.5 and int(t * 2) % 2 == 0:
            text_center(app, canvas, "ENTER - MAIN MENU", H - 26, app.font_small, (255, 230, 250), CW // 2)


class Builder:
    music = "menu"
    layout = "field"
    field_x = FIELD_X
    TOOLS = [(1, "1 HIT", "1"), (2, "2 HITS", "2"), (3, "3 HITS", "3"),
             (BOMB, "BOMB", "4"), (WALL, "WALL", "5"), (EMPTY, "ERASER", "0")]
    KEYS = {pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3, pygame.K_4: BOMB,
            pygame.K_5: WALL, pygame.K_0: EMPTY, pygame.K_e: EMPTY, pygame.K_w: WALL, pygame.K_b: BOMB}
    PALETTE_Y = GRID_BOTTOM + 18

    def __init__(self, app, slot=1):
        self.app = app
        self.tool = 1
        self.mirror = False
        self.painting = None
        self.t = 0.0
        self.msg, self.msg_t = "", 0.0
        self.confirm = None
        self.open_slot(slot)

    def open_slot(self, slot):
        self.slot = clamp(slot, 1, 99)
        g = load_custom(self.slot)
        self.grid = g if g else empty_grid()
        self.dirty = False
        self.say(f"Custom slot {self.slot}" + ("" if g else " (empty)"))

    def say(self, msg):
        self.msg, self.msg_t = msg, 3.0

    def needs_confirm(self, action):
        if not self.dirty or self.confirm == action:
            self.confirm = None
            return False
        self.confirm = action
        self.say("Unsaved changes! Press again to discard them (S to save).")
        return True

    def tool_rect(self, i):
        return pygame.Rect(16 + i * 118, self.PALETTE_Y, 110, 44)

    def paint(self, pos, erase):
        x, y = pos
        if not (GRID_TOP <= y < GRID_BOTTOM and 0 <= x < W):
            return
        c, r = int(x // TILE_W), int((y - GRID_TOP) // TILE_H)
        v = EMPTY if erase else self.tool
        cells = {(c, r)}
        if self.mirror:
            cells.add((COLS - 1 - c, r))
        for cc, rr in cells:
            if self.grid[rr][cc] != v:
                self.grid[rr][cc] = v
                self.dirty = True

    def handle_event(self, e):
        if e.type == pygame.KEYDOWN:
            k = e.key
            if k != self.confirm:
                self.confirm = None
            if k == pygame.K_ESCAPE:
                if not self.needs_confirm(k):
                    self.app.scene = Menu(self.app, sel=2)
            elif k in self.KEYS:
                self.tool = self.KEYS[k]
            elif k == pygame.K_m:
                self.mirror = not self.mirror
                self.say("Mirror drawing " + ("ON" if self.mirror else "OFF"))
            elif k == pygame.K_s:
                save_custom(self.slot, self.grid)
                self.dirty = False
                self.app.audio.play("powerup", 0.6)
                if has_breakables(self.grid):
                    self.say(f"Saved as Custom {self.slot}")
                else:
                    self.say(f"Saved - but with no breakable blocks it won't show in Custom Levels")
            elif k == pygame.K_l:
                if not self.needs_confirm(k):
                    self.open_slot(self.slot)
            elif k == pygame.K_c:
                if not self.needs_confirm(k):
                    self.grid = empty_grid()
                    self.dirty = True
                    self.say("Cleared (not saved yet)")
            elif k in (pygame.K_PAGEDOWN, pygame.K_RIGHTBRACKET):
                if not self.needs_confirm(k):
                    self.open_slot(self.slot + 1)
            elif k in (pygame.K_PAGEUP, pygame.K_LEFTBRACKET):
                if not self.needs_confirm(k):
                    self.open_slot(self.slot - 1)
            elif k == pygame.K_t:
                if has_breakables(self.grid):
                    self.app.scene = Game(self.app, [("TEST PLAY", [r[:] for r in self.grid])], builder=self)
                else:
                    self.say("Add at least one breakable block to test")
        elif e.type == pygame.MOUSEBUTTONDOWN:
            if e.button == 1:
                for i, (v, _, _) in enumerate(self.TOOLS):
                    if self.tool_rect(i).collidepoint(e.pos):
                        self.tool = v
                        self.app.audio.play("click")
                        return
            if e.button in (1, 3):
                self.painting = e.button
                self.paint(e.pos, e.button == 3)
        elif e.type == pygame.MOUSEBUTTONUP:
            if e.button == self.painting:
                self.painting = None
        elif e.type == pygame.MOUSEMOTION and self.painting:
            self.paint(e.pos, self.painting == 3)

    def update(self, dt):
        self.t += dt
        self.msg_t = max(0.0, self.msg_t - dt)

    def draw(self, surf):
        app = self.app
        surf.blit(app.bg, (0, 0))
        pygame.draw.rect(surf, (14, 14, 30), (0, 0, W, HUD_H))
        pygame.draw.line(surf, (70, 80, 150), (0, HUD_H), (W, HUD_H), 2)
        title = f"LEVEL BUILDER - CUSTOM {self.slot}" + ("  *UNSAVED*" if self.dirty else "")
        surf.blit(app.font_bold.render(title, True, (255, 255, 255)), (14, 13))
        if self.mirror:
            surf.blit(app.font_bold.render("MIRROR", True, (255, 220, 0)), (W - 110, 13))

        area = pygame.Rect(0, GRID_TOP, W, ROWS * TILE_H)
        pygame.draw.rect(surf, (20, 22, 45), area)
        for c in range(COLS + 1):
            col = (90, 80, 150) if self.mirror and c == COLS // 2 else (38, 42, 78)
            pygame.draw.line(surf, col, (c * TILE_W, GRID_TOP), (c * TILE_W, GRID_BOTTOM))
        for r in range(ROWS + 1):
            pygame.draw.line(surf, (38, 42, 78), (0, GRID_TOP + r * TILE_H), (W, GRID_TOP + r * TILE_H))
        for r in range(ROWS):
            for c in range(COLS):
                if self.grid[r][c]:
                    draw_tile(surf, self.grid[r][c], tile_rect(c, r), self.t)

        mx, my = app.mouse_pos()
        if GRID_TOP <= my < GRID_BOTTOM and 0 <= mx < W:
            c, r = int(mx // TILE_W), int((my - GRID_TOP) // TILE_H)
            cells = {(c, r)} | ({(COLS - 1 - c, r)} if self.mirror else set())
            for cc, rr in cells:
                pygame.draw.rect(surf, (255, 255, 255), tile_rect(cc, rr), 2)

        pygame.draw.rect(surf, (60, 60, 90), (W // 2 - 60, PADDLE_Y, 120, PADDLE_H), border_radius=7)

        for i, (v, name, key) in enumerate(self.TOOLS):
            r = self.tool_rect(i)
            on = v == self.tool
            pygame.draw.rect(surf, (60, 70, 140) if on else (28, 30, 60), r, border_radius=8)
            pygame.draw.rect(surf, (255, 230, 120) if on else (70, 75, 120), r, 2, border_radius=8)
            sw = pygame.Rect(r.x + 6, r.y + 9, 40, 26)
            if v == EMPTY:
                pygame.draw.line(surf, (255, 90, 90), sw.topleft, sw.bottomright, 3)
                pygame.draw.line(surf, (255, 90, 90), sw.bottomleft, sw.topright, 3)
            else:
                draw_tile(surf, v, sw.inflate(4, 4), self.t)
            surf.blit(app.font_tiny.render(name, True, (230, 230, 250)), (r.x + 50, r.y + 11))
            surf.blit(app.font_tiny.render(f"KEY {key}", True, (150, 150, 190)), (r.x + 50, r.y + 26))

        help_lines = [
            "Left mouse: paint   Right mouse: erase   M: mirror drawing   C: clear",
            "S: save   L: reload   PgUp / PgDn (or [ ]): change slot   T: test play   Esc: menu",
        ]
        for i, line in enumerate(help_lines):
            surf.blit(app.font_tiny.render(line.upper(), True, (170, 175, 215)), (18, self.PALETTE_Y + 60 + i * 20))
        if self.msg_t > 0:
            img = app.font_small.render(self.msg, True, NEON_YELLOW)
            img.set_alpha(int(255 * min(1, self.msg_t)))
            surf.blit(img, img.get_rect(midright=(W - 16, PADDLE_Y + 40)))


# --------------------------------------------------------------------------
# App: window, scaling, audio, main loop
# --------------------------------------------------------------------------
class App:
    def __init__(self):
        os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
        try:
            pygame.mixer.pre_init(44100, -16, 2, 512)
        except pygame.error:
            pass
        pygame.init()
        if pygame.mixer.get_init() is None:
            try:
                pygame.mixer.init()
            except pygame.error:
                pass
        self.settings = load_settings()
        self.desktop = self.desktop_size()
        self.icon = self.make_icon()
        self.apply_display()
        self.canvas = pygame.Surface((CW, H))
        self.field = pygame.Surface((W, H))
        self.clock = pygame.time.Clock()

        def F(name, size):
            path = os.path.join(ASSETS, "fonts", name)
            try:
                return pygame.font.Font(path, size)
            except (OSError, pygame.error, FileNotFoundError):
                return pygame.font.Font(None, int(size * 1.8))
        ARC, CY, CYB = "PressStart2P.ttf", "Orbitron-Bold.ttf", "Orbitron-Black.ttf"
        self.font_tiny = F(ARC, 8)
        self.font_small = F(ARC, 10)
        self.font_small_bold = F(ARC, 12)
        self.font = F(ARC, 12)
        self.font_bold = F(ARC, 14)
        self.font_big = F(CY, 22)
        self.font_huge = F(CYB, 58)
        self.font_title = F(CYB, 82)
        self.bg = make_background()
        self.night = make_night()
        self.stage_panel = make_stage_panel()
        self.audio = Audio(self.settings)
        sprites = os.path.join(ASSETS, "sprites")
        self.hero = self.witch = None
        try:
            if HeroStage:
                self.hero = HeroStage(sprites)
            if WitchStage:
                self.witch = WitchStage(sprites)
        except (OSError, ValueError, KeyError, pygame.error):
            self.hero = self.witch = None
        self.scene = Menu(self)
        self.running = True

    # ---------- display ----------
    @staticmethod
    def desktop_size():
        try:
            sizes = pygame.display.get_desktop_sizes()
            if sizes:
                return sizes[0]
        except (AttributeError, pygame.error):
            pass
        info = pygame.display.Info()
        return (info.current_w or 1280, info.current_h or 800)

    @staticmethod
    def make_icon():
        icon = pygame.Surface((32, 32), pygame.SRCALPHA)
        for i, col in enumerate((NEON_PINK, (170, 60, 230), NEON_CYAN)):
            pygame.draw.rect(icon, col, (2, 2 + i * 8, 28, 6), border_radius=2)
        pygame.draw.circle(icon, (255, 255, 255), (16, 26), 4)
        return icon

    def available_resolutions(self):
        dw, dh = self.desktop
        # leave room for the title bar and the taskbar so the window frame is always visible
        res = [r for r in RESOLUTIONS if r[0] <= dw and r[1] <= dh - 90]
        return res or [(800, 600)]

    def current_resolution(self):
        if self.settings["fullscreen"]:
            return tuple(self.desktop)
        r = self.settings.get("resolution")
        res = self.available_resolutions()
        if r and tuple(r) in res:
            return tuple(r)
        return max(res, key=lambda x: x[0] * x[1])

    def apply_display(self):
        size = self.current_resolution()
        if pygame.display.get_surface() is not None:
            pygame.display.quit()   # re-create so the new window is centred with its frame
            pygame.display.init()
        pygame.display.set_caption("Breaking Night")
        pygame.display.set_icon(self.icon)
        if self.settings["fullscreen"]:
            self.screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        else:
            self.screen = pygame.display.set_mode(size)
        self.update_view()

    def update_view(self):
        sw, sh = self.screen.get_size()
        scale = min(sw / CW, sh / H)
        dw, dh = int(CW * scale), int(H * scale)
        self.view = ((sw - dw) // 2, (sh - dh) // 2, scale, (dw, dh))

    def to_canvas(self, pos):
        """window pixels -> coordinates of the current scene (field scenes are offset)."""
        ox, oy, scale, _ = self.view
        fx = getattr(self.scene, "field_x", 0) if hasattr(self, "scene") else 0
        return (int((pos[0] - ox) / scale) - fx, int((pos[1] - oy) / scale))

    def mouse_pos(self):
        return self.to_canvas(pygame.mouse.get_pos())

    def present(self):
        ox, oy, scale, size = self.view
        pygame.draw.rect(self.canvas, (110, 50, 170), (0, 0, CW, H), 2)   # thin neon frame around the game
        sx, sy = getattr(self.scene, "shake_offset", (0, 0))
        img = self.canvas if size == (CW, H) else pygame.transform.smoothscale(self.canvas, size)
        self.screen.fill((0, 0, 0))
        self.screen.blit(img, (ox + sx * scale, oy + sy * scale))
        pygame.display.flip()

    # ---------- loop ----------
    def frame(self, dt, events):
        for e in events:
            if e.type == pygame.QUIT:
                self.running = False
                continue
            if hasattr(e, "pos") and e.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP):
                d = dict(e.dict)
                d["pos"] = self.to_canvas(e.pos)
                e = pygame.event.Event(e.type, d)
            self.scene.handle_event(e)
            if not self.running:
                return
        self.audio.music(getattr(self.scene, "music", "menu"))
        self.scene.update(dt)
        if getattr(self.scene, "layout", "field") == "full":
            self.scene.draw(self.canvas)
        else:
            self.scene.draw(self.field)
            self.canvas.blit(self.night, (0, 0))
            shade = pygame.Surface((CW, H), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 90))
            self.canvas.blit(shade, (0, 0))
            self.canvas.blit(self.field, (FIELD_X, 0))
            for x, col in ((FIELD_X - 3, NEON_CYAN), (FIELD_X + W + 1, NEON_PINK)):
                pygame.draw.line(self.canvas, col, (x, 0), (x, H), 2)
        self.present()

    def run(self):
        while self.running:
            dt = min(self.clock.tick(FPS) / 1000.0, 1 / 30)
            self.frame(dt, pygame.event.get())
        save_settings(self.settings)
        pygame.quit()


if __name__ == "__main__":
    App().run()
